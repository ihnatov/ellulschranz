<?php
show_admin_bar( false );
wp_head();
setup_postdata( get_post( get_the_id() ), null, false );
$style = array();
if( is_user_logged_in() ){
	$style[] = 'margin-top:-32px';
}
$style[] = 'background-color:#fff';
echo '<div class="erp-wrap" style="', esc_attr( implode( ';', $style ) ), '">';
	the_content();
echo '</div>';
wp_footer();
