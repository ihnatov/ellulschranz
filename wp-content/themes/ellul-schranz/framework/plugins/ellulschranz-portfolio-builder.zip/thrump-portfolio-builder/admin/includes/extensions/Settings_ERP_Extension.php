<?php

if( !defined( 'ERP_PATH' ) ){
	exit;
}

class Settings_ERP_Extension extends ERP_Extension_Model {

	function admin_menu(){
		add_submenu_page(
			sprintf( 'edit.php?post_type=%s', ERP_Portfolio::$post_type ),
			__( 'Portfolio Builder Settings', 'thrump-portfolio-builder' ),
			__( 'Portfolio Settings', 'thrump-portfolio-builder' ),
			'manage_options',
			'erp-portfolio-settings',
			array( $this, 'render' )
		);
	}

	function render(){
		$msg  = '';
		$tabs = array(
			'general' => esc_html( __( 'General', 'thrump-portfolio-builder' ) ),
		);
		$current = isset( $_GET['tab'] ) ? $_GET['tab'] : key( $tabs );
		$url     = admin_url( 'edit.php?post_type=%s&page=erp-portfolio-settings&tab=%s' );
		if( !array_key_exists( $current, $tabs ) ){
			$current = key( $tabs );
		}
		// save
		if( isset( $_POST['submit'], $_POST['erp_slug'] ) && is_array( $_POST['erp_slug'] ) ){
			$rewrite = array_map( 'sanitize_title_with_dashes', $_POST['erp_slug'] );
			$rewrite = array_map( 'trim', $rewrite );
			if( ! empty( $rewrite['portfolio'] ) && ! empty( $rewrite['category'] ) ){
				update_option( 'erp_portfolio_slug_rewrite', $rewrite );
				delete_option( 'rewrite_rules' );
				echo '<div class="updated"><p>' . esc_html( __( 'Portfolio slug updated successfully.', 'thrump-portfolio-builder' ) ) . '</p></div>';
			} else {
				echo '<div class="error"><p>' . esc_html( __( 'The portfolio slug cannot be empty.', 'thrump-portfolio-builder' ) ) . '</p></div>';
			}
		}
		// view
		echo '<h1>', esc_html( __( 'Portfolio Builder Settings', 'thrump-portfolio-builder' ) ), '</h1>';
		echo '<h2 class="nav-tab-wrapper">';
		foreach( $tabs as $tab => $name ){
			$class = ( $tab === $current ) ? ' nav-tab-active' : '';
			echo '<a class="nav-tab', esc_attr( $class ), '" href="', esc_attr( sprintf( $url, ERP_Portfolio::$post_type, $tab ) ), '">', esc_html( $name ), '</a>';
		}
		echo '</h2>';
		echo '<form action="', esc_attr( sprintf( $url, ERP_Portfolio::$post_type, $current ) ), '" method="post">';
		echo '<table class="form-table">';
		switch( $current ){
			case 'general':
				$slug = wp_parse_args( get_option( 'erp_portfolio_slug_rewrite', array() ), array(
					'portfolio' => ERP_Portfolio::$post_type,
					'category'  => ERP_Portfolio::$taxonomy,
				) );
				// Portfolio Slug
				echo
				'<tr>',
					'<th>', esc_html( __( 'Portfolio slug', 'thrump-portfolio-builder' ) ), '</th>',
					'<td>',
						'<input type="text" name="erp_slug[portfolio]" value="', esc_attr( $slug['portfolio'] ), '" size="60"/>',
						'<p class="description">', esc_html( __( 'Please make sure that the specified slug is unique, else it may cause internal conflict.', 'thrump-portfolio-builder' ) ), '</p>',
					'</td>',
				'</tr>';
				// Categories Slug
				echo
				'<tr>',
					'<th>', esc_html( __( 'Portfolio categories slug', 'thrump-portfolio-builder' ) ), '</th>',
					'<td>',
						'<input type="text" name="erp_slug[category]" value="', esc_attr( $slug['category'] ), '" size="60"/>',
						'<p class="description">', esc_html( __( 'Please make sure that the specified slug is unique, else it may cause internal conflict.', 'thrump-portfolio-builder' ) ), '</p>',
					'</td>',
				'</tr>';
				break;
			default:
		}
		echo '</table>';
			submit_button();
		echo '</form>';
	}

}
