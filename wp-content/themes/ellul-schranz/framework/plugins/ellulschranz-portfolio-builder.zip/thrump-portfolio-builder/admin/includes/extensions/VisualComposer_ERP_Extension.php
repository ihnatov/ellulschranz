<?php

if( !defined( 'ERP_PATH' ) ){
	exit;
}

class VisualComposer_ERP_Extension extends ERP_Extension_Model {

	function __construct(){
		if( function_exists( 'vc_map' ) ){
			vc_map( array(
				'base'             => ERP_Portfolio::$shortcode,
				'name'             => __( 'Portfolio Builder', 'thrump-portfolio-builder' ),
				'category'         => __( 'Thrump Elements', 'thrump-portfolio-builder' ),
				'description'      => __( 'Portfolio customizer', 'thrump-portfolio-builder' ),
				'admin_enqueue_js' => ERP_ADMIN_ASSETS . 'js/js_composer/validation.js',
				'icon'             => ERP_ADMIN_ASSETS . 'img/vc-icon.png',
				'params'           => array(
					// Portfolio & Grid Settings
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Portfolio', 'thrump-portfolio-builder' ),
						'param_name'  => 'build',
						'value'       => $this->get_portfolios(),
						'admin_label' => true,
						'std'         => 0,
						'group'       => __( 'Portfolio &amp; Grid Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Layout', 'thrump-portfolio-builder' ),
						'param_name'  => 'layout',
						'value'       => $this->get_layout_styles(),
						'admin_label' => true,
						'std'         => 1,
						'group'       => __( 'Portfolio &amp; Grid Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Number of columns', 'thrump-portfolio-builder' ),
						'param_name'  => 'columns',
						'value'       => $this->get_column_numbers(),
						'admin_label' => true,
						'std'         => 4,
						'group'       => __( 'Portfolio &amp; Grid Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Padding ( Gutter )', 'thrump-portfolio-builder' ),
						'param_name'  => 'gutter',
						'value'       => 0,
						'admin_label' => true,
						'group'       => __( 'Portfolio &amp; Grid Settings', 'thrump-portfolio-builder' ),
					),
					// Display Settings
					array(
						'type'        => 'checkbox',
						'heading'     => __( 'Category filtering', 'thrump-portfolio-builder' ),
						'description' => __( 'enable / disable filtering ( show / hide categories )', 'thrump-portfolio-builder' ),
						'param_name'  => 'filter',
						'std'         => true,
						'admin_label' => true,
						'group'       => __( 'Display Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Filtering alignment', 'thrump-portfolio-builder' ),
						'param_name'  => 'filter_align',
						'value'       => $this->get_alignments(),
						'std'         => 'center',
						'admin_label' => true,
						'group'       => __( 'Display Settings', 'thrump-portfolio-builder' ),
						'dependency'  => array(
							'element'   => 'filter',
							'not_empty' => true,
						),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Pagination type', 'thrump-portfolio-builder' ),
						'param_name'  => 'pagination',
						'value'       => $this->get_pagination_types(),
						'admin_label' => true,
						'std'         => 2,
						'group'       => __( 'Display Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Pagination alignment', 'thrump-portfolio-builder' ),
						'param_name'  => 'pagination_align',
						'value'       => $this->get_alignments(),
						'admin_label' => true,
						'std'         => 'center',
						'group'       => __( 'Display Settings', 'thrump-portfolio-builder' ),
						'dependency'  => array(
							'element' => 'pagination',
							'value'   => array( '2', '3' ),
						),
					),
					array(
						'type'        => 'textfield',
						'heading'     => __( 'Number of items to show / load', 'thrump-portfolio-builder' ),
						'param_name'  => 'items',
						'value'       => 8,
						'admin_label' => true,
						'group'       => __( 'Display Settings', 'thrump-portfolio-builder' ),
					),
					// Item Settings
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Image aspect ratio', 'thrump-portfolio-builder' ),
						'param_name'  => 'ratio',
						'value'       => $this->get_aspect_ratios(),
						'admin_label' => true,
						'std'         => 1,
						'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => __( 'Load items page through AJAX', 'thrump-portfolio-builder' ),
						'description' => __( 'open item`s page through Magnific Popup', 'thrump-portfolio-builder' ),
						'param_name'  => 'ajaxed',
						'std'         => true,
						'admin_label' => true,
						'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => __( 'Zoom icon', 'thrump-portfolio-builder' ),
						'param_name'  => 'zoomable',
						'std'         => true,
						'admin_label' => true,
						'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
					),
					//~ array(
						//~ 'type'        => 'checkbox',
						//~ 'heading'     => __( 'Link icon', 'thrump-portfolio-builder' ),
						//~ 'param_name'  => 'linkable',
						//~ 'std'         => true,
						//~ 'admin_label' => true,
						//~ 'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
					//~ ),
					array(
						'type'        => 'checkbox',
						'heading'     => __( 'Categories in description', 'thrump-portfolio-builder' ),
						'param_name'  => 'show_category',
						'std'         => true,
						'admin_label' => true,
						'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'checkbox',
						'heading'     => __( 'Show description', 'thrump-portfolio-builder' ),
						'param_name'  => 'description',
						'std'         => true,
						'admin_label' => true,
						'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
					),
					array(
						'type'        => 'dropdown',
						'heading'     => __( 'Description position', 'thrump-portfolio-builder' ),
						'param_name'  => 'desc_position',
						'value'       => $this->get_description_positions(),
						'admin_label' => true,
						'std'         => 1,
						'group'       => __( 'Item Settings', 'thrump-portfolio-builder' ),
						'dependency'  => array(
							'element'   => 'description',
							'not_empty' => true,
						),
					),
				),
			) );
		}
	}

	private function get_portfolios(){
		$data  = array(
			__( 'Choose your portfolio', 'thrump-portfolio-builder' ) => 0,
		);
		$args  = array(
			'hide_empty' => false,
		);
		$terms = get_terms( Builder_ERP_Extension::$taxonomy, $args );
		if( $terms && !is_wp_error( $terms ) ){
			for( $i = 0, $c = count( $terms ); $i < $c; $i++ ){
				$title   = $terms[ $i ]->name;
				$details = isset( $terms[ $i ]->description ) ? @unserialize( $terms[ $i ]->description ) : false;
				if( isset( $details['meta']['description'] ) && !empty( $details['meta']['description'] ) ){
					$title .= sprintf( ' - %s...', trim( substr( $details['meta']['description'], 0, 20 ) ) );
				}
				$data[ esc_html( $title ) ] = $terms[ $i ]->slug;
			}
		}
		return $data;
	}

	private function get_aspect_ratios(){
		return array(
			__( '1 : auto ( default )', 'thrump-portfolio-builder' ) => 1,
			__( '1 : 1', 'thrump-portfolio-builder' )                => 2,
			__( '16 : 9', 'thrump-portfolio-builder' )               => 3,
		);
	}

	private function get_pagination_types(){
		return array(
			__( 'None', 'thrump-portfolio-builder' )                         => 1,
			__( 'Load More Button ( default )', 'thrump-portfolio-builder' ) => 2,
			__( 'Paginated', 'thrump-portfolio-builder' )                    => 3,
		);
	}

	private function get_column_numbers(){
		return array(
			__( '2 columns', 'thrump-portfolio-builder' )             => 2,
			__( '3 columns', 'thrump-portfolio-builder' )             => 3,
			__( '4 columns ( default )', 'thrump-portfolio-builder' ) => 4,
			__( '5 columns', 'thrump-portfolio-builder' )             => 5,
		);
	}

	private function get_layout_styles(){
		return array(
			__( 'Masonry ( default )', 'thrump-portfolio-builder' ) => 'masonry',
			__( 'Fit Rows', 'thrump-portfolio-builder' )            => 'fitRows',
		);
	}

	private function get_description_positions(){
		return array(
			__( 'Inside ( default )', 'thrump-portfolio-builder' ) => 1,
			__( 'Outside', 'thrump-portfolio-builder' )            => 2,
		);
	}

	private function get_alignments(){
		return array(
			__( 'Left', 'thrump-portfolio-builder' )               => 'left',
			__( 'Center ( default )', 'thrump-portfolio-builder' ) => 'center',
			__( 'Right', 'thrump-portfolio-builder' )              => 'right',
		);
	}

}
