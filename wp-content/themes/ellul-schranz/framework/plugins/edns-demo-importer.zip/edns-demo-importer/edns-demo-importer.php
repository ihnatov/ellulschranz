<?php
/*
Plugin Name: EDNS Demo Importer
Plugin URI: http://www.europadns.com
Description: Theme demo content importer
Author: Mujnoi Tamas @ EuropaDNS
Version: 1.1.1
Author URI: http://www.europadns.com
Text Domain: edns-demo-importer
*/

if( !defined( 'ABSPATH' ) ){ exit; }

/**********************************************************************
* Define Constants
**********************************************************************/

define( 'EDC_PATH', plugin_dir_path( __FILE__ ) );
define( 'EDC_INCLUDES', trailingslashit( EDC_PATH . 'includes' ) );
define( 'EDC_ASSETS', plugins_url( 'assets/', __FILE__ ) );

/**********************************************************************
* GET PLUGIN INFORMATION
**********************************************************************/

class EDC_PLUGIN {

	static $plugin_meta;

	static public function GET( $key ){
		if( is_null( self::$plugin_meta ) ){
			self::$plugin_meta = get_plugin_data( __FILE__ );
		}
		if( array_key_exists( $key, self::$plugin_meta ) ){
			return self::$plugin_meta[ $key ];
		}
	}

	static public function load_textdomain(){
		load_plugin_textdomain( 'edns-demo-importer', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	static private function register_hooks(){
		add_action( 'admin_init', array( 'EDC_PLUGIN', 'load_textdomain' ) );
	}

	static public function init(){
		self::register_hooks();
		include_once EDC_INCLUDES . 'init.php';
	}

}

/**********************************************************************
* Init plugin
**********************************************************************/

add_action( 'plugins_loaded', array( 'EDC_PLUGIN', 'init' ) );
