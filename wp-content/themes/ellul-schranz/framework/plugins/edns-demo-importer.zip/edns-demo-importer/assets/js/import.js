(function($){
	var importing = 0, warning_timeout = null;
	// importer
	function Importer(){
		this._sequences = [];
		this._authorization = {};
		this.dispatch = function(){
			if( this._sequences.length ){
				this.post( this._sequences.shift() );
			}
		}
	}
	Importer.prototype.authorize = function( key, value ){
		this._authorization[ key ] = value;
	};
	Importer.prototype.load = function( $sequence ){
		if( ! $sequence.length ) return;
		var _seq = {};
		$sequence.each(function(){
			_seq[ this.name ] = this.value;
		});
		this._sequences.push(
			$.extend( _seq, this._authorization )
		);
	};
	Importer.prototype.fire = function(){
		importing = this._sequences.length;
		$('#edc-error').html('');
		$('#edc-success').html('');
		$('#edc-info').show();
		$(document).scrollTop(0);
		this.dispatch();
	};
	Importer.prototype.post = function( data ){
		var self = this;
		$.post(EDC_AJAX.url,data,function(d){
			if( d.failes ){
				var msg = '', fail = 0;
				if( d.failes.xml && d.failes.xml.length ){
					msg += '<strong>' + EDC_AJAX.i18n.failed_to_import_xml + '</strong><ul>';
					for( var i in d.failes.xml ){
						msg += '<li>' + d.failes.xml[ i ] + '</li>';
					}
					msg += '</ul>';
					fail++;
				}
				if( d.failes.redux && d.failes.redux.length ){
					msg += '<strong>' + EDC_AJAX.i18n.failed_to_import_redux + '</strong><ul>';
					for( var i in d.failes.redux ){
						msg += '<li>' + d.failes.redux[ i ] + '</li>';
					}
					msg += '</ul>';
					fail++;
				}
				if( d.failes.revslider && d.failes.revslider.length ){
					msg += '<strong>' + EDC_AJAX.i18n.failed_to_import_revslider + '</strong><ul>';
					for( var i in d.failes.revslider ){
						msg += '<li>' + d.failes.revslider[ i ] + '</li>';
					}
					msg += '</ul>';
					fail++;
				}
				if( fail ){
					$('#edc-error').show().append(msg);
				}
			}
			if( d.success ){
				if( d.imported ){
					var msg = '';
					if( d.imported.xml && d.imported.xml.length ){
						msg += '<strong>' + EDC_AJAX.i18n.successfully_imported_xml + '</strong><ul>';
						for( var i in d.imported.xml ){
							msg += '<li>' + d.imported.xml[ i ] + '</li>';
						}
						msg += '</ul>';
					}
					if( d.imported.redux && d.imported.redux.length ){
						msg += '<strong>' + EDC_AJAX.i18n.successfully_imported_redux + '</strong><ul>';
						for( var i in d.imported.redux ){
							msg += '<li>' + d.imported.redux[ i ] + '</li>';
						}
						msg += '</ul>';
					}
					if( d.imported.revslider && d.imported.revslider.length ){
						msg += '<strong>' + EDC_AJAX.i18n.successfully_imported_revslider + '</strong><ul>';
						for( var i in d.imported.revslider ){
							msg += '<li>' + d.imported.revslider[ i ] + '</li>';
						}
						msg += '</ul>';
					}
					msg = msg || d.data;
					$('#edc-success').show().append(msg);
				}
			}
			importing--;
			if( importing ){
				self.dispatch();
			} else {
				$('#edc-info').hide();
			}
		},'json').fail(function(xhr){
			var	response = '<strong>XHR ERROR</strong>';
			if( xhr.responseText ){
				response += '<br/><pre>' + xhr.responseText + '</pre>';
			}
			$('#edc-error').show().append(response);
			importing--;
			if( importing ){
				self.dispatch();
			} else {
				$('#edc-info').hide();
			}
		});
	};
	// submits
	$('#edc-form').on('submit',function(e){
		e.preventDefault();
		if( ! importing ){
			$('.edc-alert-toggle:not(#edc-info)').hide();
			if( $( '.edc-import:checked', this ).length ){
				// init importer
				var $import = new Importer();
				// fill authorization
				$('.edc-authorizer').each(function(){
					$import.authorize( this.name, this.value );
				});
				// load sequence
				$import.load( $( '.edc-import[name*="xml"]:checked', this ) );
				$import.load( $( '.edc-import[name*="redux"]:checked', this ) );
				$import.load( $( '.edc-import[name*="revslider"]:checked', this ) );
				// fire importer
				$import.fire();
			} else {
				$('#edc-warning').show().find('p').html( EDC_AJAX.i18n.select_option );
			}
		} else {
			$('#edc-warning').show().find('p').html( EDC_AJAX.i18n.import_in_progress );
			clearTimeout( warning_timeout );
			warning_timeout = setTimeout( function(){
				$('#edc-warning').fadeOut();
			}, 2000 );
		}
	});
	$('.edc-toggle-subpackage').on('click',function(){
		var $subpak = $(this).next();
		if( $subpak.is(':visible') ){
			$subpak.hide();
			$( 'i', this )
				.removeClass('dashicons-arrow-up-alt2')
				.addClass('dashicons-arrow-down-alt2');
		} else {
			$subpak.show();
			$( 'i', this )
				.removeClass('dashicons-arrow-down-alt2')
				.addClass('dashicons-arrow-up-alt2');
		}
	});
	$('.edc-option').on('change',function(){
		var $imports = $(this).siblings('.edc-sub-export').find('.edc-import');
		$imports.prop( 'checked', ( this.checked ? true : false ) );
	});
	$('.edc-import').on('change',function(){
		var $subexport = $(this).closest('.edc-sub-export');
		$subexport.siblings('.edc-option').prop( 'checked', (
			$subexport.find('.edc-import').length == $subexport.find('.edc-import:checked').length
		) );
	});
})(jQuery);
