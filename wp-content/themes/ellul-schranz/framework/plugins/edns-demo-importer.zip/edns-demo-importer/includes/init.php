<?php
/**
 * EDNS Demo Content Init File
 *
 * @package EDC
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

final class EDC_Manager {

	const   IMPORT_XML       = 1,
			IMPORT_REVSLIDER = 2,
			IMPORT_REDUX     = 4;
	private	$hook, $bitmask = 0,
			$defaults = array(),
			$imports = array(
				'xml'       => array(),
				'redux'     => array(),
				'revslider' => array(),
			);

	public function __construct(){
		$this->defaults = $this->imports;
		add_action( 'init', array( $this, 'init' ) );
		add_action( 'admin_init', array( $this, 'register_wordpress_importer' ), 999 );
	}

	public function init(){
		$defaults = array(
			'xml'       => array(),
			'redux'     => array(),
			'revslider' => array(),
		);
		$imports = apply_filters( 'edc-demo-content', array() );
		if( is_array( $imports ) && ! empty( $imports ) ){
			foreach( $imports as $path => $list ){
				$import = array();
				$path   = trailingslashit( ! is_int( $path ) ? $path : get_template_directory() );
				$list   = wp_parse_args( $list, $this->defaults );
				// array filter
				$list['xml']       = $this->array_filter( $list['xml'] );
				$list['redux']     = $this->array_filter( $list['redux'] );
				$list['revslider'] = $this->array_filter( $list['revslider'] );
				// populate & flag demo content
				if( ! empty( $list['xml'] ) ){
					$import['xml']  = $this->prefix_location( $path, $list['xml'] );
					$this->bitmask |= self::IMPORT_XML;
				}
				if( ! empty( $list['redux'] ) ){
					$import['redux'] = $this->prefix_location( $path, $list['redux'] );
					$this->bitmask  |= self::IMPORT_REDUX;
				}
				if( ! empty( $list['revslider'] ) ){
					$import['revslider'] = $this->prefix_location( $path, $list['revslider'] );
					$this->bitmask      |= self::IMPORT_REVSLIDER;
				}
				if( ! empty( $import ) ){
					if( isset( $import['xml'] ) ){
						$this->imports['xml'] = array_merge( $this->imports['xml'], $import['xml'] );
					}
					if( isset( $import['redux'] ) ){
						$this->imports['redux'] = array_merge( $this->imports['redux'], $import['redux'] );
					}
					if( isset( $import['revslider'] ) ){
						$this->imports['revslider'] = array_merge( $this->imports['revslider'], $import['revslider'] );
					}
				}
			}
		}
		if( $this->bitmask ){
			// run array_unique and array_values to remove duplicate entries and then reset the index keys
			// we don't need to run array_unique on redux key since its string index based
			$this->imports['xml']       = array_values( array_unique( $this->imports['xml'] ) );
			$this->imports['revslider'] = array_values( array_unique( $this->imports['revslider'] ) );
			$this->register_importer_page();
		}
	}

	public function prefix_location( $path, $arr ){
		if( is_array( $arr ) && ! empty( $arr ) ){
			foreach( $arr as $k => $v ){
				$arr[ $k ] = $path . $v;
			}
			return $arr;
		}
	}

	public function array_filter( $arr ){
		return is_array( $arr ) ? array_filter( $arr ) : null;
	}

	private function register_importer_page(){
		add_action( 'admin_menu', array( $this, 'admin_menu' ), 11 );
		add_action( 'admin_enqueue_scripts', array( $this, 'scripts' ) );
		add_action( 'wp_ajax_edc_import', array( $this, 'import' ) );
	}

	public function register_wordpress_importer(){
		if( defined( 'WP_LOAD_IMPORTERS' ) && ! isset( $GLOBALS['wp_import'] ) ){
			require_once EDC_INCLUDES . '/wp-import/wordpress-importer.php';
			$GLOBALS['wp_import'] = new EDC_WP_Import();
			register_importer( 'wordpress', 'WordPress', __( 'Import <strong>posts, pages, comments, custom fields, categories, and tags</strong> from a WordPress export file.', 'edns-demo-importer' ), array( $GLOBALS['wp_import'], 'dispatch' ) );
		}
	}

	public function scripts( $hook ){
		if( $hook == $this->hook ){
			wp_enqueue_style( 'edc-import', EDC_ASSETS . 'css/import.css', null, EDC_PLUGIN::GET( 'Version' ) );
			wp_enqueue_script( 'edc-import', EDC_ASSETS . 'js/import.js', array( 'jquery' ), EDC_PLUGIN::GET( 'Version' ), true );
			wp_localize_script( 'edc-import', 'EDC_AJAX', array(
				'url'  => admin_url( 'admin-ajax.php' ),
				'i18n' => array(
					'import_in_progress'              => esc_html__( 'This action is unavailable. Import in progress.', 'edns-demo-importer' ),
					'select_option'                   => esc_html__( 'Please check one of the available import option.', 'edns-demo-importer' ),
					'failed_to_import_xml'            => esc_html__( 'Failed to import the following XML files:', 'edns-demo-importer' ),
					'failed_to_import_redux'          => esc_html__( 'Failed to import the following Redux Theme Option files:', 'edns-demo-importer' ),
					'failed_to_import_revslider'      => esc_html__( 'Failed to import the following Revolution Slider ZIP files:', 'edns-demo-importer' ),
					'successfully_imported_xml'       => esc_html__( 'Successfully imported the following XML files:', 'edns-demo-importer' ),
					'successfully_imported_redux'     => esc_html__( 'Successfully imported the following Redux Theme Option files:', 'edns-demo-importer' ),
					'successfully_imported_revslider' => esc_html__( 'Successfully imported the following Revolution Slider ZIP files:', 'edns-demo-importer' ),
				),
			) );
		}
	}

	public function admin_menu(){
		$this->hook = add_theme_page(
			__( 'Demo Content', 'edns-demo-importer' ),
			__( 'Demo Content', 'edns-demo-importer' ),
			'manage_options',
			'edc-demo-import',
			array( $this, 'render_page' )
		);
	}

	public function render_page(){
		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Demo Content Importer', 'edns-demo-importer' ); ?></h1>
			<div class="edc-content">
				<div id="edc-info" class="edc-alert edc-alert-toggle edc-alert-info hide">
					<img src="<?php echo EDC_ASSETS; ?>images/loader.gif" alt="<?php esc_attr_e( 'Loading...', 'edns-demo-importer' ); ?>"/>
					<h1><?php esc_html_e( 'Importing demo content...', 'edns-demo-importer' ); ?></h1>
					<p>
						<?php echo wp_kses(
							__( 'Please be patient and <strong>do not navigate away</strong> from this page while the import is in progress. This may take some time.', 'edns-demo-importer' ),
							array( 'strong' => array(), )
						); ?>
					</p>
				</div>
				<div id="edc-success" class="edc-alert edc-alert-toggle edc-alert-success hide"></div>
				<div id="edc-error" class="edc-alert edc-alert-toggle edc-alert-error hide"></div>
				<div id="edc-warning" class="edc-alert edc-alert-toggle edc-alert-warning hide">
					<h1><?php esc_html_e( 'Warning!', 'edns-demo-importer' ); ?></h1>
					<p></p>
				</div>
				<div class="edc-alert edc-alert-content">
					<form id="edc-form" action="#" method="post">
						<p>
							<?php echo wp_kses(
								__( 'Select from the options below which type of data you want to import. <strong>If you want to import the demo content for plugins ( ex. Contactform 7, Revolution Slider, WooCommerce, etc. ), make sure to install them before running the Importer!</strong>', 'edns-demo-importer' ),
								array( 'strong' => array(), )
							); ?>
						</p>
						<div class="edc-row">
							<div class="edc-col-left">
								<?php if( self::IMPORT_XML === ( self::IMPORT_XML & $this->bitmask ) ): ?>
								<section>
									<input type="checkbox" id="edc-xml" class="edc-option css-checkbox" checked="checked" autocomplete="off"/>
									<label for="edc-xml" class="css-label"><?php esc_html_e( 'Import WordPress Contents', 'edns-demo-importer' ); ?></label>
									<span class="edc-toggle-subpackage"><i class="dashicons dashicons-arrow-down-alt2"></i></span>
									<ul class="edc-sub-export">
										<?php foreach( $this->imports['xml'] as $key => $xml ): ?>
											<li>
												<input type="checkbox" name="xml[<?php echo esc_attr( $key ); ?>]" class="edc-import css-checkbox" id="edc-xml-<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $key ); ?>" checked="checked" autocomplete="off"/>
												<label for="edc-xml-<?php echo esc_attr( $key ); ?>" class="css-label x-checkbox">
													<?php echo esc_html( basename( $xml ) ); ?>
												</label>
											</li>
										<?php endforeach; ?>
									</ul>
								</section>
								<?php endif; ?>
								<?php if( class_exists( 'Redux' ) && self::IMPORT_REDUX === ( self::IMPORT_REDUX & $this->bitmask ) ): ?>
								<section>
									<input type="checkbox" id="edc-redux" class="edc-option css-checkbox" checked="checked" autocomplete="off"/>
									<label for="edc-redux" class="css-label"><?php esc_html_e( 'Import ReduxFramework Options', 'edns-demo-importer' ); ?></label>
									<span class="edc-toggle-subpackage"><i class="dashicons dashicons-arrow-down-alt2"></i></span>
									<ul class="edc-sub-export">
										<?php foreach( $this->imports['redux'] as $key => $redux ): ?>
											<li>
												<input type="checkbox" name="redux[<?php echo esc_attr( $key ); ?>]" class="edc-import css-checkbox" id="edc-redux-<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $key ); ?>" checked="checked" autocomplete="off"/>
												<label for="edc-redux-<?php echo esc_attr( $key ); ?>" class="css-label x-checkbox">
													<?php echo '<strong>', esc_html( $key ), ':</strong> ', esc_html( basename( $redux ) ); ?>
												</label>
											</li>
										<?php endforeach; ?>
									</ul>
								</section>
								<?php endif; ?>
								<?php if( class_exists( 'RevSlider' ) && self::IMPORT_REVSLIDER === ( self::IMPORT_REVSLIDER & $this->bitmask ) ): ?>
								<section>
									<input type="checkbox" id="edc-revslider" class="edc-option css-checkbox" checked="checked" autocomplete="off"/>
									<label for="edc-revslider" class="css-label"><?php esc_html_e( 'Import Revolution Slider Demo Sliders', 'edns-demo-importer' ); ?></label>
									<span class="edc-toggle-subpackage"><i class="dashicons dashicons-arrow-down-alt2"></i></span>
									<ul class="edc-sub-export">
										<?php foreach( $this->imports['revslider'] as $key => $revslider ): ?>
											<li>
												<input type="checkbox" name="revslider[<?php echo esc_attr( $key ); ?>]" class="edc-import css-checkbox" id="edc-revslider-<?php echo esc_attr( $key ); ?>" value="<?php echo esc_attr( $key ); ?>" checked="checked" autocomplete="off"/>
												<label for="edc-revslider-<?php echo esc_attr( $key ); ?>" class="css-label x-checkbox">
													<?php echo esc_html( basename( $revslider ) ); ?>
												</label>
											</li>
										<?php endforeach; ?>
									</ul>
								</section>
								<?php endif; ?>
								<button type="submit" name="submit" class="button-primary button-large "><?php esc_html_e( 'Import', 'edns-demo-importer' ); ?></button>
							</div>
							<div class="edc-col-right">
								<p><?php esc_html_e( 'Side notes:', 'edns-demo-importer' ); ?></p>
								<ol>
									<li><?php esc_html_e( 'We recommend to run the Demo Import on a clean WordPress installation.', 'edns-demo-importer' ); ?></li>
									<li>
										<?php echo wp_kses(
											__( 'To reset your installation (if the import fails) we recommend <a href="https://wordpress.org/plugins/wordpress-reset/" target="_blank">Wordpress Reset Plugin</a>.', 'edns-demo-importer' ),
											array( 'a' => array( 'href' => array(), 'target' => array() ), )
										); ?>
									</li>
									<li><?php esc_html_e( 'Do not run the Demo Import multiple times, it will result in duplicated content.', 'edns-demo-importer' ); ?></li>
								</ol>
							</div>
						</div>
						<input type="hidden" name="action" value="edc_import" class="edc-authorizer" />
						<input type="hidden" name="edc-nonce" value="<?php echo esc_attr( wp_create_nonce( 'edc-demo-importer' ) ); ?>" class="edc-authorizer" />
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	public function import(){
		if( isset( $_POST['edc-nonce'] ) && wp_verify_nonce( $_POST['edc-nonce'], 'edc-demo-importer' ) ){
			$imported = 0;
			$failes   = array();
			$success  = array();
			// buffer all outputs from each API's
			ob_start();
			// import WP XML content
			if( isset( $_POST['xml'] ) && is_array( $_POST['xml'] ) && ! empty( $this->imports['xml'] ) ){
				global $wpdb;
				if( ! defined( 'WP_LOAD_IMPORTERS' ) ){
					define( 'WP_LOAD_IMPORTERS', true );
				}
				require_once ABSPATH . 'wp-admin/includes/import.php';
				if( ! class_exists( 'WP_Importer' ) ){
					$class_wp_importer = ABSPATH . 'wp-admin/includes/class-wp-importer.php';
					if( file_exists( $class_wp_importer ) ){
						require_once $class_wp_importer;
					}
				}
				if( ! class_exists( 'EDC_WP_Import' ) ){
					$class_wp_importer = EDC_INCLUDES . '/wp-import/wordpress-importer.php';
					if( file_exists( $class_wp_importer ) ){
						require_once $class_wp_importer;
					}
				}
				if( class_exists( 'EDC_WP_Import' ) ){
					$wp_import = new EDC_WP_Import;
					$wp_import->fetch_attachments = true;
					foreach( $_POST['xml'] as $xml ){
						if( isset( $this->imports['xml'][ $xml ] ) ){
							$file = $this->imports['xml'][ $xml ];
							if( file_exists( $file ) ){
								$wp_import->import( $file );
								$success['xml'][] = esc_html( basename( $file ) );
								$imported++;
							} else {
								$failes['xml'][] = esc_html( $file );
							}
						}
					}
				}
			}
			// import Redux Framework options
			if( isset( $_POST['redux'] ) && is_array( $_POST['redux'] ) && class_exists( 'ReduxFrameworkInstances' ) && ! empty( $this->imports['redux'] ) ){
				foreach( $_POST['redux'] as $option ){
					if( isset( $this->imports['redux'][ $option ] ) ){
						$redux_conf = $this->imports['redux'][ $option ];
						if( file_exists( $redux_conf ) ){
							$redux_options  = json_decode( file_get_contents( $redux_conf ), true );
							$ReduxFramework = ReduxFrameworkInstances::get_instance( $option );
							if( method_exists( $ReduxFramework, 'set_options' ) ){
								$ReduxFramework->set_options( $redux_options );
								$success['redux'][] = esc_html( basename( $redux_conf ) );
								$imported++;
							} else {
								$failes['redux'][] = esc_html( $redux_conf );
							}
							unset( $ReduxFramework );
						} else {
							$failes['redux'][] = esc_html( $redux_conf );
						}
					}
				}
			}
			// import Revolution Slider slides
			if( isset( $_POST['revslider'] ) && is_array( $_POST['revslider'] ) && class_exists( 'RevSlider' ) && ! empty( $this->imports['revslider'] ) ){
				foreach( $_POST['revslider'] as $slider_zip ){
					if( isset( $this->imports['revslider'][ $slider_zip ] ) ){
						$file = $this->imports['revslider'][ $slider_zip ];
						if( file_exists( $file ) ){
							$_FILES['import_file']['tmp_name'] = $file;
							$RevSlider = new RevSlider();
							$RevSlider->importSliderFromPost();
							$success['revslider'][] = esc_html( basename( $file ) );
							$imported++;
							unset( $RevSlider );
						} else {
							$failes['revslider'][] = esc_html( $file );
						}
					}
				}
			}
			// disregard any output, since we're outputing JSON
			ob_end_clean();
			if( $imported ){
				wp_send_json( array(
					'success'  => true,
					'data'     => 'IMPORTS_OK',
					'failes'   => $failes,
					'imported' => $success,
				) );
			}
			wp_send_json( array(
				'success' => false,
				'data'    => __( 'Sorry, but we couldn&#8217;t import your selected file(s).', 'edns-demo-importer' ),
				'failes'  => $failes,
			) );
		}
		wp_send_json_error( __( 'Unable to verify nonce. Please refresh your page.', 'edns-demo-importer' ) );
    }

}

new EDC_Manager;
