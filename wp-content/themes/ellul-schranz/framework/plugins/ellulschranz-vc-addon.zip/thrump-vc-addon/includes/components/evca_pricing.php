<?php
/**
 * EDNS VISUAL COMPOSER Pricing Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Pricing extends EVCA_Shortcode {

	private $currency_place = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title'     => '',
			'features'  => '',
			'link'      => '',
			'price'     => 30,
			'decimal'   => '.',
			'thousand'  => ',',
			'currency'  => '',
			'cur_place' => '',
			'period'    => esc_html_x( 'month', 'EVCA Pricing', 'thrump-vc-addon' ),
			'class'     => '',
		), $atts );
		$atts['class'] = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'pricing-table' ) );
		$atts['link']  = EVCA_PLUGIN::FILTER_LINK( $atts['link'] );
		$abs_price     = abs( $atts['price'] + 0 );
		$decimals = 0;
		if( is_float( $abs_price ) ){
			$decimals = 2;
		}

		$atts['price'] = number_format( $atts['price'], $decimals, $atts['decimal'], $atts['thousand'] );
		$price         = 'after' == $atts['cur_place'] ?
			$atts['price'] . $atts['currency'] :
			$atts['currency'] . $atts['price'];
		$output = sprintf( '<div class="%s">', esc_attr( $atts['class'] ) );
		$output.= sprintf(
			'<div class="pricing-table-header">
				<h4>%s</h4>
				<h1>
					%s
					<small>/%s</small>
				</h1>
			</div>',
			esc_html( $atts['title'] ), esc_html( $price ), esc_html( $atts['period'] )
		);
		if( ! empty( $atts['features'] ) ){
			$features = explode( ',', $atts['features'] );
			$features = array_map( 'esc_html', $features );
			$features = sprintf( '<li>%s</li>', implode( '</li><li>', $features ) );
			$output  .= sprintf(
				'<div class="pricing-table-offer">
					<ul>%s</ul>
				</div>',
				$features
			);
		}
		if( ! empty( $atts['link']['url'] ) && ! empty( $atts['link']['title'] ) ){
			$output.= sprintf(
				'<a href="%s" target="%s" class="btn btn-grey">%s</a>',
				esc_url( $atts['link']['url'] ),
				esc_attr( $atts['link']['target'] ),
				esc_html( $atts['link']['title'] )
			);
		}
		$output.= '</div>';
		return $output;
	}

	protected function map(){
		return array(
			'name'   => esc_html_x( 'Pricing Table', 'EVCA Pricing', 'thrump-vc-addon' ),
			'params' => array(
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Plan name', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'exploded_textarea',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Plan features', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Add one per line or comma ( , ) separated', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'features',
				),
				array(
					'type'        => 'vc_link',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Link', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify an optional link pointing to a details page', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'link',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'group'      => esc_html_x( 'Price Settings', 'EVCA Pricing', 'thrump-vc-addon' ),
					'heading'    => esc_html_x( 'Period', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name' => 'period',
					'value'      => esc_html_x( 'month', 'EVCA Pricing', 'thrump-vc-addon' ),
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Price Settings', 'EVCA Pricing', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Price', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Can be integer or decimal, the decimal separator must be a dot( . ). Ex. Interger: 30 | Decimal: 5.99', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'price',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Price Settings', 'EVCA Pricing', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Decimal separator', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Used for price formating [ default: dot ( . ) ]', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'decimal',
					'value'       => '.',
					'dependency'  => array(
						'element'   => 'price',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Price Settings', 'EVCA Pricing', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Thousand separator', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Used for price formating [ default: comma ( , ) ]', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'thousand',
					'value'       => ',',
					'dependency'  => array(
						'element'   => 'price',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Price Settings', 'EVCA Pricing', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Currency symbol', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Can be a string or an html entity. Ex: USD or $', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'currency',
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Price Settings', 'EVCA Pricing', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Currency placement', 'EVCA Pricing', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Used for price formating [ default: dot ( . ) ]', 'EVCA Pricing', 'thrump-vc-addon' ),
					'param_name'  => 'cur_place',
					'value'       => $this->currency_place,
					'std'         => $this->currency_place[ key( $this->currency_place ) ],
					'dependency'  => array(
						'element'   => 'currency',
						'not_empty' => true,
					),
				),
			),
		);
	}

	protected function pre_register(){
		$this->currency_place = array(
			esc_html_x( 'Before price', 'EVCA Pricing', 'thrump-vc-addon' ) => 'before',
			esc_html_x( 'After price', 'EVCA Pricing', 'thrump-vc-addon' )  => 'after',
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_pricing extends WPBakeryShortCode {}
}

new EVCA_Pricing;
