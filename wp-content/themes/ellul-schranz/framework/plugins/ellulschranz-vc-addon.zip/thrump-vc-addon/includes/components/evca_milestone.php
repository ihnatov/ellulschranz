<?php
/**
 * EDNS VISUAL COMPOSER Milestone Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Milestone extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title' => '',
			'text'  => '',
			'stop'  => 100,
			'speed' => 2000,
			'class' => '',
		), $atts );
		$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'milestone' ) );
		$stop  = absint( $atts['stop'] );
		$speed = absint( $atts['speed'] );
		$text  = '';
		if( ! empty( $atts['text'] ) ){
			$text  = wpautop( $atts['text'], true );
		}
		return sprintf(
			'<div class="%s">
				<div class="milestone-content">
					<span class="milestone-value" data-stop="%u" data-speed="%u"></span>
					<div class="milestone-description">
						<h6>%s</h6>
						%s
					</div>
				</div>
			</div>',
			esc_attr( $class ), esc_attr( $stop ), esc_attr( $speed ),
			esc_html( $atts['title'] ), $text
		);
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Milestone', 'EVCA Milestone', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Shows milestones and numeric statistic with animated numbers', 'EVCA Milestone', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Title', 'EVCA Milestone', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the title of the Milestone', 'EVCA Milestone', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Description', 'EVCA Milestone', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the description of the Milestone', 'EVCA Milestone', 'thrump-vc-addon' ),
					'param_name'  => 'text',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Numeric value', 'EVCA Milestone', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Numeric value representing the milestone', 'EVCA Milestone', 'thrump-vc-addon' ),
					'param_name'  => 'stop',
					'value'       => 100,
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Speed', 'EVCA Milestone', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the animation speed', 'EVCA Milestone', 'thrump-vc-addon' ),
					'param_name'  => 'speed',
					'value'       => 2000,
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Milestone', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Milestone', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_milestone extends WPBakeryShortCode {}
}

new EVCA_Milestone;
