<?php
/**
 * EDNS VISUAL COMPOSER Alerts Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Alert extends EVCA_Shortcode {

	protected $alerts, $a_data;

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'type'  => '',
			'class' => '',
		), $atts );
		$class = array( 'alert' );
		$icon  = '';
		if( $atts['type'] && in_array( $atts['type'], $this->alerts ) ){
			$class[] = sanitize_html_class( $atts['type'] );
			if( isset( $this->a_data[ $atts['type'] ]['icon'] ) && $this->a_data[ $atts['type'] ]['icon'] ){
				$icon = sprintf( '<i class="%s"></i>', esc_attr( $this->a_data[ $atts['type'] ]['icon'] ) );
			}
		}
		$class = esc_attr( EVCA_PLUGIN::FILTER_CLASS( $atts['class'], $class ) );
		return sprintf( '<div class="%s">%s%s</div>', esc_attr( $class ), $icon, wp_strip_all_tags( $content, true ) );
	}

	protected function map(){
		$alerts = array();
		foreach( $this->a_data as $val => $opts ){
			if( isset( $opts['title'] ) ){
				$alerts[ $opts['title'] ] = $val;
			}
		}
		return array(
			'name'        => esc_html_x( 'Alert', 'EVCA Alert', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Use to display notifications', 'EVCA Alert', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Alert type', 'EVCA Alert', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the content of the message', 'EVCA Alert', 'thrump-vc-addon' ),
					'param_name'  => 'type',
					'value'       => $alerts,
					'std'         => key( $alerts ),
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Message', 'EVCA Alert', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the content of the message', 'EVCA Alert', 'thrump-vc-addon' ),
					'param_name'  => 'content',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Alert', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Alert', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->alerts = array( 'default', 'info', 'success', 'warning', 'error' );
		$this->a_data = array(
			'default' => array(
				'title' => esc_html_x( 'Default', 'EVCA Alert', 'thrump-vc-addon' ),
				'icon'  => '',
				'class' => 'default',
			),
			'info'    => array(
				'title' => esc_html_x( 'Info', 'EVCA Alert', 'thrump-vc-addon' ),
				'icon'  => 'ifc-info',
				'class' => 'info',
			),
			'success' => array(
				'title' => esc_html_x( 'Success', 'EVCA Alert', 'thrump-vc-addon' ),
				'icon'  => 'ifc-checkmark',
				'class' => 'success',
			),
			'warning' => array(
				'title' => esc_html_x( 'Warning', 'EVCA Alert', 'thrump-vc-addon' ),
				'icon'  => 'ifc-error',
				'class' => 'warning',
			),
			'error'   => array(
				'title' => esc_html_x( 'Error', 'EVCA Alert', 'thrump-vc-addon' ),
				'icon'  => 'ifc-close',
				'class' => 'error',
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_alert extends WPBakeryShortCode {}
}

new EVCA_Alert;
