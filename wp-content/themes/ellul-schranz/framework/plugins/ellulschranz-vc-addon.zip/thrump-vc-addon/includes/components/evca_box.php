<?php
/**
 * EDNS VISUAL COMPOSER Boxes Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Box extends EVCA_Shortcode {

	private $boxes = array(),
			$index = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'style' => '',
			'class' => '',
		), $atts );
		$classes = array( 'box' );
		if( $atts['style'] && in_array( $atts['style'], $this->index ) ){
			$classes[] = $atts['style'];
		}
		$classes = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], $classes );
		return sprintf( '<div class="%s">%s</div>', esc_attr( $classes ), wp_kses_post( $content ) );
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Text Box', 'EVCA Boxes', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Add boxed content', 'EVCA Boxes', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'        => 'evca_image_select',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Box style', 'EVCA Boxes', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the type of box', 'EVCA Boxes', 'thrump-vc-addon' ),
					'param_name'  => 'style',
					'value'       => $this->boxes,
					'std'         => $this->boxes[ key( $this->boxes ) ],
				),
				array(
					'type'        => 'textarea_html',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Content', 'EVCA Alert', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the content of the box', 'EVCA Alert', 'thrump-vc-addon' ),
					'param_name'  => 'content',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Boxes', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Boxes', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->index = array( 'default', 'box-style-1', 'box-style-2' );
		$this->boxes = array(
			EVCA_ASSETS . 'images/textbox-1.jpg' => 'default',
			EVCA_ASSETS . 'images/textbox-2.jpg' => 'box-style-1',
			EVCA_ASSETS . 'images/textbox-3.jpg' => 'box-style-2',
		);
	}

}


if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_box extends WPBakeryShortCode {}
}

new EVCA_Box;
