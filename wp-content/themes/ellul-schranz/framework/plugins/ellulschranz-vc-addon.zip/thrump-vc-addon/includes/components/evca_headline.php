<?php
/**
 * EDNS VISUAL COMPOSER Headline Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Headline extends EVCA_Shortcode {

	private $heading = array(),
			$align   = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title'    => '',
			'subtitle' => '',
			'heading'  => 'h3',
			'align'    => '',
			'class'    => '',
		), $atts );
		// default classes
		$class = array( 'headline' );
		// aligment
		if( $atts['align'] && in_array( $atts['align'], $this->align ) ){
			$class[] = sanitize_html_class( $atts['align'] );
		}
		// combine classes
		$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], $class );
		// heading
		if( $atts['heading'] && in_array( $atts['heading'], $this->heading ) ){
			$heading = sprintf( '<%1$s>%%s</%1$s>', esc_html( $atts['heading'] ) );
		} else {
			$heading = '<h3>%s<h3>';
		}
		$heading = sprintf( $heading, esc_html( $atts['title'] ) );
		// subtitle
		$subtitle = '';
		if( ! empty( $atts['subtitle'] ) ){
			$subtitle = sprintf( '<p>%s</p>', esc_html( $atts['subtitle'] ) );
		}
		return sprintf( '<div class="%s">%s%s</div>', esc_attr( $class ), $heading, $subtitle );
	}

	protected function map(){
		return array(
			'name'   => esc_html_x( 'Headline', 'EVCA Headline', 'thrump-vc-addon' ),
			'params' => array(
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Title', 'EVCA Headline', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the text of the headline', 'EVCA Headline', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Sub title', 'EVCA Headline', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Optional text under headline', 'EVCA Headline', 'thrump-vc-addon' ),
					'param_name'  => 'subtitle',
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Heading', 'EVCA Headline', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the heading size ( from h1 to h6 )', 'EVCA Headline', 'thrump-vc-addon' ),
					'param_name'  => 'heading',
					'value'       => $this->heading,
					'std'         => 'h3',
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Alignment', 'EVCA Headline', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'How the headline should be aligned', 'EVCA Headline', 'thrump-vc-addon' ),
					'param_name'  => 'align',
					'value'       => $this->align,
					'std'         => $this->align[ key( $this->align ) ],
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Headline', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Headline', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->heading = array(
			esc_html_x( 'Heading 1', 'EVCA Headline', 'thrump-vc-addon' ) => 'h1',
			esc_html_x( 'Heading 2', 'EVCA Headline', 'thrump-vc-addon' ) => 'h2',
			esc_html_x( 'Heading 3', 'EVCA Headline', 'thrump-vc-addon' ) => 'h3',
			esc_html_x( 'Heading 4', 'EVCA Headline', 'thrump-vc-addon' ) => 'h4',
			esc_html_x( 'Heading 5', 'EVCA Headline', 'thrump-vc-addon' ) => 'h5',
			esc_html_x( 'Heading 6', 'EVCA Headline', 'thrump-vc-addon' ) => 'h6',
		);
		$this->align   = array(
			esc_html_x( 'Left', 'EVCA Headline', 'thrump-vc-addon' )   => 'left',
			esc_html_x( 'Center', 'EVCA Headline', 'thrump-vc-addon' ) => 'center',
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_headline extends WPBakeryShortCode {}
}

new EVCA_Headline;
