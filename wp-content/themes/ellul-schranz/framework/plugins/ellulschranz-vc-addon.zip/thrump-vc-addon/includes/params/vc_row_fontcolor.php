<?php
/**
 * EDNS VISUAL COMPOSER VC Row Font Color Param
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_VC_Row_FontColor {

	private $selector = 'custom-color-selected evca-font-color-';

	function __construct(){
		add_filter( VC_SHORTCODE_CUSTOM_CSS_FILTER_TAG, array( $this, 'filter_css' ), 999, 3 );
		add_filter( 'vc_shortcode_content_filter_after', array( $this, 'filter_vc_row' ), 999, 2 );
		$this->add_param();
	}

	function add_param(){
		vc_add_param( 'vc_row', array(
			'type'        => 'colorpicker',
			'group'       => esc_html_x( 'Design Options', 'EVCA vc_row', 'thrump-vc-addon' ),
			'heading'     => esc_html_x( 'Font color', 'EVCA vc_row', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Select a font color for this row', 'EVCA vc_row', 'thrump-vc-addon' ),
			'param_name'  => 'font_color',
		) );
	}

	function filter_css( $css_class, $base, $atts ){
		if( $base === 'vc_row' && isset( $atts['font_color'] ) && ! empty( $atts['font_color'] ) ){
			$css_class .= esc_attr( ' ' . $this->selector . $atts['font_color'] );
		}
		return $css_class;
	}

	function filter_vc_row( $output, $shortcode ){
		if( $shortcode === 'vc_row' && ( $start_pos = strpos( $output, $this->selector . '#' ) ) !== false ){
			$length = strlen( $this->selector . '#' );
			$string = substr( $output, $start_pos + $length, 6 );
			if( preg_match( '/^([A-Fa-f0-9]{6}|[A-Fa-f0-9]{3})/', $string, $match ) && ! empty( $match[0] ) ){
				$start  = strpos( $output, ' ' );
				$output = sprintf(
					'%s style="color:#%s" %s',
					substr( $output, 0, $start ), esc_attr( $match[0] ), substr( $output, $start )
				);
			}
		}
		return $output;
	}

}

new EVCA_VC_Row_FontColor;
