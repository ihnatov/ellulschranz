<?php
/**
 * EDNS VISUAL COMPOSER Google Maps Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_GMap extends EVCA_Shortcode {

	private $map_types = array( 'ROADMAP', 'SATELLITE', 'HYBRID', 'TERRAIN' );

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'address' => 'Jacksonville, USA',
			'popup'   => false,
			'type'    => $this->map_types[0],
			'zoom'    => 16,
			'height'  => 400,
			'class'   => '',
		), $atts );
		$attributes = array(
			'class' => array( 'google-map' ),
		);
		$attributes['data-address']   = esc_attr( $atts['address'] );
		$attributes['data-caption']   = esc_attr( wp_kses_post( $content ) );
		$attributes['data-popup']     = esc_attr( $atts['popup'] ? 'true' : 'false' );
		$attributes['data-maptype']   = esc_attr( in_array( $atts['type'], $this->map_types ) ? $atts['type'] : $this->map_types[0] );
		$attributes['data-zoom']      = absint( $atts['zoom'] );
		$attributes['data-mapheight'] = absint( $atts['height'] );
		$attributes['class']          = esc_attr( EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'google-map' ) ) );
		$result = '';
		foreach( $attributes as $a => $v ){
			$result .= sprintf( ' %s="%s"', $a, $v );
		}
		return sprintf( '<div class="map"><div%s></div></div>', $result );
	}

	protected function scripts(){
		global $thrump_edns_data;
		$key = isset( $thrump_edns_data['google-api-key'] ) ? esc_attr( $thrump_edns_data['google-api-key'] ) : '';
		wp_enqueue_script( 'google-maps', sprintf( '//maps.google.com/maps/api/js?key=%s', $key ), null, null, true );
		wp_enqueue_script( 'gmap', EVCA_ASSETS . 'vendors/gmap/jquery.gmap.min.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
	}

	protected function map(){
		return array(
			'name'   => esc_html_x( 'Google Map', 'EVCA GMap', 'thrump-vc-addon' ),
			'params' => array(
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Address', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'The address where the map is centered', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'address',
				),
				array(
					'type'        => 'textarea_html',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Pinpoint caption', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify text that will appear when you click on the pin', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'content',
				),
				array(
					'type'        => 'checkbox',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Show caption', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Open caption popup by default', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'popup',
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Map type', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the map type', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'type',
					'value'       => $this->map_types,
					'std'         => $this->map_types[0],
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Zoom', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify a zoom value between 5 and 20', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'zoom',
					'value'       => 16,
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Map height', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the height of the map', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'height',
					'value'       => 400,
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA GMap', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA GMap', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			)
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_gmap extends WPBakeryShortCode {}
}

new EVCA_GMap;
