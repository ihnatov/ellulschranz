<?php
/**
 * EDNS VISUAL COMPOSER Buttons Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Button extends EVCA_Shortcode {

	private $btn_color = array(),
			$btn_size  = array(),
			$align     = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'icon_pos'     => 'left',
			'color'        => 'btn-default',
			'border_color' => '',
			'bg_color'     => '',
			'text_color'   => '',
			'size'         => 'btn-normal',
			'link'         => '',
			'icon'         => '',
			'align'        => '',
			'class'        => '',
		), $atts );
		// generate link array
		$atts['link'] = EVCA_PLUGIN::FILTER_LINK( $atts['link'] );
		// setup default attributes
		$attributes = array(
			'class' => array( 'btn' ),
		);
		// href
		$attributes['href']   = esc_url( $atts['link']['url'] ? $atts['link']['url'] : '#' );
		// target
		$attributes['target'] = esc_attr( $atts['link']['target'] ? $atts['link']['target'] : '' );
		// link text
		$text                 = esc_html( $atts['link']['title'] ? $atts['link']['title'] : _x( 'Button', 'EVCA Button', 'thrump-vc-addon' ) );
		// icon
		if( ! empty( $atts['icon'] ) ){
			$text = sprintf( '<i class="%s"></i>', esc_attr( $atts['icon'] ) ) . $text;
		}
		// button color
		if( $atts['color'] && in_array( $atts['color'], $this->btn_color ) ){
			$attributes['class'][] = sanitize_html_class( $atts['color'] );
		}
		// custom button colors
		if( 'btn-custom' == $atts['color'] ){
			$attributes['style']   = array();
			$attributes['style'][] = sprintf( 'border-color:%s', $atts['border_color'] );
			$attributes['style'][] = sprintf( 'background-color:%s', $atts['bg_color'] );
			$attributes['style'][] = sprintf( 'color:%s', $atts['text_color'] );
			$attributes['style']   = implode( ';', $attributes['style'] );
			$attributes['style']   = esc_attr( $attributes['style'] );
		}
		// button size
		if( $atts['size'] && in_array( $atts['size'], $this->btn_size ) ){
			$attributes['class'][] = sanitize_html_class( $atts['size'] );
		}
		// extra class
		$attributes['class'] = esc_attr( EVCA_PLUGIN::FILTER_CLASS( $atts['class'], $attributes['class'] ) );
		// alignment
		$alignment           = esc_attr( in_array( $atts['align'], $this->align ) ? $atts['align'] : $this->align[ key( $this->align ) ] );
		// combine
		$result = '';
		foreach( $attributes as $a => $v ){
			$result .= sprintf( ' %s="%s"', $a, $v );
		}
		return sprintf( '<p class="%s"><a%s>%s</a></p>', $alignment, $result, $text );
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Button', 'EVCA Button', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Customizable button with text and icon', 'EVCA Button', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'        => 'vc_link',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Link title &amp; URL', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the link pointing to another page', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'link',
				),
				array(
					'type'        => 'iconpicker',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Icon', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select icon from library.', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'icon',
					'settings'    => array(
						'emptyIcon'    => true,
						'type'         => 'icon-font-custom',
						'iconsPerPage' => 200,
					),
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design options', 'EVCA Button', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Button Color', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the type size of the button', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'color',
					'value'       => $this->btn_color,
					'std'         => $this->btn_color[ key( $this->btn_color ) ],
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design options', 'EVCA Button', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Button Border Color', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the border color', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'border_color',
					'value'       => '#232323',
					'dependency'  => array(
						'element' => 'color',
						'value'   => 'btn-custom',
					),
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design options', 'EVCA Button', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Button Background Color', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the color of the text on button', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'bg_color',
					'value'       => '#232323',
					'dependency'  => array(
						'element' => 'color',
						'value'   => 'btn-custom',
					),
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design options', 'EVCA Button', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Button Text Color', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the color of the button', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'text_color',
					'value'       => '#ffffff',
					'dependency'  => array(
						'element' => 'color',
						'value'   => 'btn-custom',
					),
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Button Size', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the type size of the button', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'size',
					'value'       => $this->btn_size,
					'std'         => $this->btn_size[ key( $this->btn_size ) ],
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Alignment', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'How the button should be aligned', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'align',
					'value'       => $this->align,
					'std'         => $this->align[ key( $this->align ) ],
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Extra Class Name', 'EVCA Button', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Button', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->btn_color = array(
			esc_html_x( 'Default', 'EVCA Button', 'thrump-vc-addon' ) => 'btn-default',
			esc_html_x( 'Grey', 'EVCA Button', 'thrump-vc-addon' )    => 'btn-grey',
			esc_html_x( 'Custom', 'EVCA Button', 'thrump-vc-addon' )  => 'btn-custom',
		);
		$this->btn_size  = array(
			esc_html_x( 'Normal', 'EVCA Button', 'thrump-vc-addon' ) => 'btn-normal',
			esc_html_x( 'Large', 'EVCA Button', 'thrump-vc-addon' )  => 'btn-large',
		);
		$this->align = array(
			esc_html_x( 'Left', 'EVCA Icon Box', 'thrump-vc-addon' )   => 'text-left',
			esc_html_x( 'Center', 'EVCA Icon Box', 'thrump-vc-addon' ) => 'text-center',
			esc_html_x( 'Right', 'EVCA Icon Box', 'thrump-vc-addon' )  => 'text-right',
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_button extends WPBakeryShortCode {}
}

new EVCA_Button;
