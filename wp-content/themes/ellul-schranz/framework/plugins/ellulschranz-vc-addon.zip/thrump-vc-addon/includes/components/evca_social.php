<?php
/**
 * EDNS VISUAL COMPOSER Social Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Social extends EVCA_Shortcode {

	protected $social = array(), $atts = array();

	protected function render( $atts, $content = '' ){
		$class  = isset( $atts['class'] ) ? $atts['class'] : '';
		$class  = EVCA_PLUGIN::FILTER_CLASS( $class, array( 'fixed', 'social-media' ) );
		$social = shortcode_atts( $this->atts, $atts );
		$output = '';
		foreach( $social as $icon => $url ){
			if( ! empty( $url ) ){
				$output.= sprintf(
					'<a class="%1$s-icon social-icon" href="%2$s" target="_blank"><i class="fa fa-%1$s"></i></a>',
					esc_attr( $icon ), esc_url( $url )
				);
			}
		}
		return sprintf( '<div class="%s">%s</div>', esc_attr( $class ), $output );
	}

	protected function map(){
		$params = array();
		foreach( $this->social as $social => $text ){
			$params[] = array(
				'type'       => 'textfield',
				'heading'    => $text,
				'param_name' => $social,
			);
		}
		$params[] = array(
			'type'        => 'textfield',
			'heading'     => esc_html_x( 'Extra class name', 'EVCA Social', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Social', 'thrump-vc-addon' ),
			'param_name'  => 'class',
		);
		return array(
			'name'        => esc_html_x( 'Social', 'EVCA Social', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Add social media links', 'EVCA Social', 'thrump-vc-addon' ),
			'params'      => $params,
		);
	}

	protected function pre_register(){
		$this->social = array(
			'facebook'       => esc_html_x( 'Facebook URL:', 'EVCA Social', 'stone_edns' ),
			'twitter'        => esc_html_x( 'Twitter URL:', 'EVCA Social', 'stone_edns' ),
			'dribbble'       => esc_html_x( 'Dribbble URL:', 'EVCA Social', 'stone_edns' ),
			'pinterest'      => esc_html_x( 'Pinterest URL:', 'EVCA Social', 'stone_edns' ),
			'google-plus'    => esc_html_x( 'Google+ URL:', 'EVCA Social', 'stone_edns' ),
			'tumblr'         => esc_html_x( 'Tumblr URL:', 'EVCA Social', 'stone_edns' ),
			'instagram'      => esc_html_x( 'Instagram URL:', 'EVCA Social', 'stone_edns' ),
			'rss'            => esc_html_x( 'RSS URL:', 'EVCA Social', 'stone_edns' ),
			'linkedin'       => esc_html_x( 'LinkedIn URL:', 'EVCA Social', 'stone_edns' ),
			'skype'          => esc_html_x( 'Skype URL:', 'EVCA Social', 'stone_edns' ),
			'flickr'         => esc_html_x( 'Flickr URL:', 'EVCA Social', 'stone_edns' ),
			'vimeo-square'   => esc_html_x( 'Vimeo URL:', 'EVCA Social', 'stone_edns' ),
			'github'         => esc_html_x( 'Github URL:', 'EVCA Social', 'stone_edns' ),
			'youtube'        => esc_html_x( 'Youtube URL:', 'EVCA Social', 'stone_edns' ),
			'windows'        => esc_html_x( 'Windows URL:', 'EVCA Social', 'stone_edns' ),
			'dropbox'        => esc_html_x( 'Dropbox URL:', 'EVCA Social', 'stone_edns' ),
			'xing'           => esc_html_x( 'Xing URL:', 'EVCA Social', 'stone_edns' ),
			'adn'            => esc_html_x( 'ADN URL:', 'EVCA Social', 'stone_edns' ),
			'android'        => esc_html_x( 'Android URL:', 'EVCA Social', 'stone_edns' ),
			'apple'          => esc_html_x( 'Apple URL:', 'EVCA Social', 'stone_edns' ),
			'behance'        => esc_html_x( 'Behance URL:', 'EVCA Social', 'stone_edns' ),
			'bitbucket'      => esc_html_x( 'Bitbucket URL:', 'EVCA Social', 'stone_edns' ),
			'bitcoin'        => esc_html_x( 'Bitcoin URL:', 'EVCA Social', 'stone_edns' ),
			'codepen'        => esc_html_x( 'Codepen URL:', 'EVCA Social', 'stone_edns' ),
			'css3'           => esc_html_x( 'CSS3 URL:', 'EVCA Social', 'stone_edns' ),
			'delicious'      => esc_html_x( 'Delicious URL:', 'EVCA Social', 'stone_edns' ),
			'deviantart'     => esc_html_x( 'Deviantart URL:', 'EVCA Social', 'stone_edns' ),
			'digg'           => esc_html_x( 'Digg URL:', 'EVCA Social', 'stone_edns' ),
			'drupal'         => esc_html_x( 'Drupal URL:', 'EVCA Social', 'stone_edns' ),
			'empire'         => esc_html_x( 'Empire URL:', 'EVCA Social', 'stone_edns' ),
			'foursquare'     => esc_html_x( 'Four Square URL:', 'EVCA Social', 'stone_edns' ),
			'git'            => esc_html_x( 'Git URL:', 'EVCA Social', 'stone_edns' ),
			'gittip'         => esc_html_x( 'Gittip URL:', 'EVCA Social', 'stone_edns' ),
			'hacker-news'    => esc_html_x( 'Hacker News URL:', 'EVCA Social', 'stone_edns' ),
			'html5'          => esc_html_x( 'HTML5 URL:', 'EVCA Social', 'stone_edns' ),
			'joomla'         => esc_html_x( 'Joomla URL:', 'EVCA Social', 'stone_edns' ),
			'jsfiddle'       => esc_html_x( 'jsFiddle URL:', 'EVCA Social', 'stone_edns' ),
			'linux'          => esc_html_x( 'Linux URL:', 'EVCA Social', 'stone_edns' ),
			'maxcdn'         => esc_html_x( 'Maxcdn URL:', 'EVCA Social', 'stone_edns' ),
			'openid'         => esc_html_x( 'OpenID URL:', 'EVCA Social', 'stone_edns' ),
			'pagelines'      => esc_html_x( 'Pagelines URL:', 'EVCA Social', 'stone_edns' ),
			'pied-piper'     => esc_html_x( 'Pied Piper URL:', 'EVCA Social', 'stone_edns' ),
			'qq'             => esc_html_x( 'QQ URL:', 'EVCA Social', 'stone_edns' ),
			'rebel'          => esc_html_x( 'Rebel URL:', 'EVCA Social', 'stone_edns' ),
			'reddit'         => esc_html_x( 'Reddit URL:', 'EVCA Social', 'stone_edns' ),
			'renren'         => esc_html_x( 'RenRen URL:', 'EVCA Social', 'stone_edns' ),
			'share'          => esc_html_x( 'Share URL:', 'EVCA Social', 'stone_edns' ),
			'slack'          => esc_html_x( 'Slack URL:', 'EVCA Social', 'stone_edns' ),
			'soundcloud'     => esc_html_x( 'SoundCloud URL:', 'EVCA Social', 'stone_edns' ),
			'spotify'        => esc_html_x( 'Spotify URL:', 'EVCA Social', 'stone_edns' ),
			'stack-exchange' => esc_html_x( 'StackExchange URL:', 'EVCA Social', 'stone_edns' ),
			'stack-overflow' => esc_html_x( 'StackOverflow URL:', 'EVCA Social', 'stone_edns' ),
			'steam'          => esc_html_x( 'Steam URL:', 'EVCA Social', 'stone_edns' ),
			'stumbleupon'    => esc_html_x( 'Stumbleupon URL:', 'EVCA Social', 'stone_edns' ),
			'tencent-weibo'  => esc_html_x( 'Tencent Weibo URL:', 'EVCA Social', 'stone_edns' ),
			'trello'         => esc_html_x( 'Trello URL:', 'EVCA Social', 'stone_edns' ),
			'vine'           => esc_html_x( 'Vine URL:', 'EVCA Social', 'stone_edns' ),
			'vk'             => esc_html_x( 'VK URL:', 'EVCA Social', 'stone_edns' ),
			'wechat'         => esc_html_x( 'WeChat URL:', 'EVCA Social', 'stone_edns' ),
			'weibo'          => esc_html_x( 'Weibo URL:', 'EVCA Social', 'stone_edns' ),
			'wordpress'      => esc_html_x( 'WordPress URL:', 'EVCA Social', 'stone_edns' ),
			'yahoo'          => esc_html_x( 'Yahoo URL:', 'EVCA Social', 'stone_edns' ),
		);
		foreach( $this->social as $social => $text ){
			$this->atts[ $social ] = '';
		}
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_social extends WPBakeryShortCode {}
}

new EVCA_Social;
