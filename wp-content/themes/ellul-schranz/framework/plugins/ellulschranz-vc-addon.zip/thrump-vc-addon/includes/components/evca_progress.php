<?php
/**
 * EDNS VISUAL COMPOSER Progress Bar Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Progress extends EVCA_Shortcode {

	private $style = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title'       => '',
			'style'       => '',
			'percentage'  => 90,
			'bar_color'   => '#0084b4',
			'track_color' => '#e1e1e1',
			'class'       => '',
		), $atts );
		$class      = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'fixed' ) );
		$percentage = absint( $atts['percentage'] );
		$percentage = $percentage > 0 && $percentage <= 100 ? $percentage : 90;
		if( ! empty( $atts['style'] ) && $atts['style'] == 'progressbar-2' ){
			return sprintf(
				'<div class="%1$s">
					<div class="progress-bar alt" style="background-color:%5$s">
						<span class="progress-bar-outer" data-width="%3$u" data-progress-bar-outer-color="%4$s">
							<span class="progress-bar-inner"></span>
						</span>
					</div>
					<div class="progress-bar-description">
						%2$s
						<span>%3$u%%</span>
					</div>
				</div>',
				esc_attr( $class ), esc_html( $atts['title'] ), esc_attr( $percentage ),
				esc_attr( $atts['bar_color'] ), esc_attr( $atts['track_color'] )
			);
		}
		return sprintf(
			'<div class="%1$s">
				<div class="progress-bar-description">
					%2$s
					<span>%3$u%%</span>
				</div>
				<div class="progress-bar" style="background-color:%5$s">
					<span class="progress-bar-outer" data-width="%3$u" data-progress-bar-outer-color="%4$s">
						<span class="progress-bar-inner"></span>
					</span>
				</div>
			</div>',
			esc_attr( $class ), esc_html( $atts['title'] ), esc_attr( $percentage ),
			esc_attr( $atts['bar_color'] ), esc_attr( $atts['track_color'] )
		);
	}

	protected function map(){
		return array(
			'name'   => esc_html_x( 'Progress Bar', 'EVCA Progress Bar', 'thrump-vc-addon' ),
			'params' => array(
				array(
					'type'       => 'evca_image_select',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Progress bar style', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'param_name' => 'style',
					'value'      => $this->style,
					'std'        => $this->style[ key( $this->style ) ],
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Progress bar title', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the title of the Progress bar', 'EVCA Pie', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Pie chart percentage', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify a percentage between 1 and 100', 'EVCA Pie', 'thrump-vc-addon' ),
					'param_name' => 'percentage',
					'value'      => 90,
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design Options', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Bar Color', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the color of the bar', 'EVCA Pie', 'thrump-vc-addon' ),
					'param_name'  => 'bar_color',
					'value'       => '#0084b4',
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design Options', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Track Color', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the color of the track', 'EVCA Pie', 'thrump-vc-addon' ),
					'param_name'  => 'track_color',
					'value'       => '#e1e1e1',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Progress Bar', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->style = array(
			EVCA_ASSETS . 'images/progressbar-1.png' => 'progressbar-1',
			EVCA_ASSETS . 'images/progressbar-2.png' => 'progressbar-2',
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_progress extends WPBakeryShortCode {}
}

new EVCA_Progress;
