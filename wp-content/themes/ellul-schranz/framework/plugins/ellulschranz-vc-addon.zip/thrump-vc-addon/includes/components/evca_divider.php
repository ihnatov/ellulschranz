<?php
/**
 * EDNS VISUAL COMPOSER Divider Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Divider extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'type'  => '',
			'class' => '',
		), $atts );
		$class   = array( 'divider' );
		$class[] = 'double-line' == $atts['type'] ? 'double-line' : 'single-line';
		$class   = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], $class );
		return sprintf( '<div class="%s">%s</div>', esc_attr( $class ), do_shortcode( $content ) );
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Divider', 'EVCA Divider', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Use it to divide content', 'EVCA Divider', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Divider Style', 'EVCA Divider', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the type of the line', 'EVCA Divider', 'thrump-vc-addon' ),
					'param_name'  => 'type',
					'value' => array(
						esc_html_x( 'Single line', 'EVCA Divider', 'thrump-vc-addon' ) => 'single-line',
						esc_html_x( 'Double line', 'EVCA Divider', 'thrump-vc-addon' ) => 'double-line',
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Divider', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Divider', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_divider extends WPBakeryShortCode {}
}

new EVCA_Divider;
