<?php
/**
 * EDNS VISUAL COMPOSER Vertical Process Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_VP_Parent extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'class' => '',
		), $atts );
		$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'vertical-process-builder' ) );
		return sprintf( '<ul class="%s">%s</ul>', esc_attr( $class ), do_shortcode( $content ) );
	}

	protected function map(){
		return array(
			'name'                    => esc_html_x( 'Our Process Vertical', 'EVCA Process Vertical Parent', 'thrump-vc-addon' ),
			'description'             => esc_html_x( 'Display a step by step vertical process list', 'EVCA Process Vertical Parent', 'thrump-vc-addon' ),
			'as_parent'               => array(
				'only' => 'evca_vp',
			),
			'show_settings_on_create' => false,
			'js_view'                 => 'VcColumnView',
			'params'                  => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Process Vertical Parent', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Process Vertical Parent', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

class EVCA_VP extends EVCA_Shortcode {

	private $indicator_type = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'type'   => '',
			'icon'   => '',
			'number' => '',
			'title'  => '',
			'text'   => '',
			'class'  => '',
		), $atts );
		$class  = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'process-description' ) );
		$output = '<li>';
		if( 'icon' === $atts['type'] ){
			$output.= sprintf( '<i class="%s"></i>', esc_attr( $atts['icon'] ) );
		} else {
			$output.= sprintf( '<h1>%u</h1>', absint( $atts['number'] ) );
		}
		$output.= sprintf(
			'<div class="%s"><h4>%s</h4>',
			esc_attr( $class ),
			esc_html( $atts['title'] )
		);
		if( ! empty( $atts['text'] ) ){
			$output.= sprintf( '<p>%s</p>', esc_html( $atts['text'] ) );
		}
		$output.= '</div></li>';
		return $output;
	}

	protected function map(){
		return array(
			'name'     => esc_html_x( 'Process Step', 'EVCA Process Vertical', 'thrump-vc-addon' ),
			'as_child' => array(
				'only' => 'evca_vp_parent',
			),
			'params'   => array(
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Process indicator', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'param_name'  => 'type',
					'value'       => $this->indicator_type,
					'std'         => $this->indicator_type[ key( $this->indicator_type ) ],
				),
				array(
					'type'        => 'iconpicker',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Process Icon', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select icon from library.', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'param_name'  => 'icon',
					'settings'    => array(
						'emptyIcon'    => true,
						'type'         => 'icon-font-custom',
						'iconsPerPage' => 200,
					),
					'dependency'  => array(
						'element' => 'type',
						'value'   => 'icon',
					),
				),
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Process number', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'param_name' => 'number',
					'value'      => 0,
					'dependency' => array(
						'element' => 'type',
						'value'   => 'number',
					),
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Title', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the title of the process', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Description', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Add description text for the process', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'param_name'  => 'text',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Process Vertical', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->indicator_type = array(
			esc_html_x( 'Number', 'EVCA Process Vertical', 'thrump-vc-addon' ) => 'number',
			esc_html_x( 'Icon', 'EVCA Process Vertical', 'thrump-vc-addon' )   => 'icon',
		);
	}

}

if( class_exists( 'WPBakeryShortCodesContainer' ) ){
	class WPBakeryShortCode_EVCA_vp_parent extends WPBakeryShortCodesContainer {}
}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_vp extends WPBakeryShortCode {}
}

new EVCA_VP_Parent;

new EVCA_VP;
