<?php
/**
 * EDNS VISUAL COMPOSER Pie Chart Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Pie extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title'       => '',
			'percentage'  => 90,
			'size'        => 230,
			'width'       => 5,
			'bar_color'   => '#0084b4',
			'track_color' => '#ffffff',
			'class'       => '',
		), $atts );
		$attributes = array(
			'class' => EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'pie-chart' ) ),
		);
		$attributes['data-percent']    = absint( $atts['percentage'] );
		$attributes['data-percent']    = $attributes['data-percent'] > 0 && $attributes['data-percent'] <= 100 ? $attributes['data-percent'] : 90;
		$attributes['data-barColor']   = $atts['bar_color'];
		$attributes['data-trackColor'] = $atts['track_color'];
		$attributes['data-lineWidth']  = absint( $atts['width'] );
		$attributes['data-lineWidth']  = $attributes['data-lineWidth'] > 0 ? $attributes['data-lineWidth'] : 5;
		$attributes['data-barSize']    = absint( $atts['size'] );
		$attributes['data-barSize']    = $attributes['data-barSize'] > 0 ? $attributes['data-barSize'] : 230;
		$result = '';
		foreach( $attributes as $attribute => $value ){
			$result.= sprintf( ' %s="%s"', $attribute, esc_attr( $value ) );
		}
		$output = sprintf(
			'<div%s>
				<div class="pie-chart-percent">
					<span></span>
					<sup>%%</sup>
				</div>
				<span class="pie-chart-custom-text">%s</span>
			</div>', $result, esc_html( $atts['title'] )
		);
		return $output;
	}

	protected function scripts(){
		wp_enqueue_script( 'easypiechart', EVCA_ASSETS . 'vendors/easypiechart/jquery.easypiechart.min.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
	}

	protected function map(){
		return array(
			'name'   => esc_html_x( 'Pie Chart', 'EVCA Pie Chart', 'thrump-vc-addon' ),
			'params' => array(
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Pie chart title', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the title of the Pie Chart', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Pie chart percentage', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify a percentage between 1 and 100', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name' => 'percentage',
					'value'      => 90,
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design Options', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Bar size', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Represents the bar size of the piechart measured in pixels', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name'  => 'size',
					'value'       => 230,
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design Options', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Line width', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Represents the line width of the piechart', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name'  => 'width',
					'value'       => 5,
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design Options', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Bar Color', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the color of the bar', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name'  => 'bar_color',
					'value'       => '#0084b4',
				),
				array(
					'type'        => 'colorpicker',
					'holder'      => 'div',
					'group'       => esc_html_x( 'Design Options', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Track Color', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the color of the track', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name'  => 'track_color',
					'value'       => '#ffffff',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Pie Chart', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_Pie extends WPBakeryShortCode {}
}

new EVCA_Pie;
