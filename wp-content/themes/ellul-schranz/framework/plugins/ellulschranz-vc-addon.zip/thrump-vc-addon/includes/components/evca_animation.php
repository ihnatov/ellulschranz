<?php
/**
 * EDNS VISUAL COMPOSER Animation Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Animation extends EVCA_Shortcode {

	private $effects = array(
		'bounce', 'flash', 'pulse', 'rubberBand', 'shake', 'swing', 'tada', 'wobble', 'jello', 'bounceIn', 'bounceInDown', 'bounceInLeft', 'bounceInRight', 'bounceInUp', 'bounceOut', 'bounceOutDown', 'bounceOutLeft', 'bounceOutRight', 'bounceOutUp', 'fadeIn', 'fadeInDown', 'fadeInDownBig', 'fadeInLeft', 'fadeInLeftBig', 'fadeInRight', 'fadeInRightBig', 'fadeInUp', 'fadeInUpBig', 'fadeOut', 'fadeOutDown', 'fadeOutDownBig', 'fadeOutLeft', 'fadeOutLeftBig', 'fadeOutRight', 'fadeOutRightBig', 'fadeOutUp', 'fadeOutUpBig', 'flip', 'flipInX', 'flipInY', 'flipOutX', 'flipOutY', 'lightSpeedIn', 'lightSpeedOut', 'rotateIn', 'rotateInDownLeft', 'rotateInDownRight', 'rotateInUpLeft', 'rotateInUpRight', 'rotateOut', 'rotateOutDownLeft', 'rotateOutDownRight', 'rotateOutUpLeft', 'rotateOutUpRight', 'slideInUp', 'slideInDown', 'slideInLeft', 'slideInRight', 'slideOutUp', 'slideOutDown', 'slideOutLeft', 'slideOutRight', 'zoomIn', 'zoomInDown', 'zoomInLeft', 'zoomInRight', 'zoomInUp', 'zoomOut', 'zoomOutDown', 'zoomOutLeft', 'zoomOutRight', 'zoomOutUp', 'hinge', 'rollIn', 'rollOut'
	);

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'effect' => '',
			'delay'  => '',
			'speed'  => '',
			'offset' => '',
			'class'  => '',
		), $atts );
		if( $atts['effect'] && in_array( $atts['effect'], $this->effects ) ){
			$attributes['data-animation'] = esc_attr( $atts['effect'] );
		}
		if( $atts['delay'] && ( (float) $atts['delay'] > 0 ) ){
			$attributes['data-animation-delay'] = esc_attr( ( float ) $atts['delay'] );
		}
		if( $atts['speed'] && ( (float) $atts['speed'] > 0 ) ){
			$attributes['data-animation-speed'] = esc_attr( $atts['speed'] );
		}
		if( $atts['offset'] && ( (float) $atts['offset'] > 0 ) ){
			$attributes['data-animation-offset'] = esc_attr( $atts['offset'] );
			if( strpos( $atts['offset'], '%' ) === false ){
				$attributes['data-animation-offset'] .= '%';
			}
		}
		$attributes['class'] = esc_attr( EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'animate' ) ) );
		$result = '';
		foreach( $attributes as $a => $v ){
			$result .= sprintf( ' %s="%s"', $a, $v );
		}
		return sprintf( '<div%s>%s</div>', $result, do_shortcode( $content ) );
	}

	protected function styles(){
		wp_enqueue_style( 'evca-animation', EVCA_ASSETS . 'vendors/animations/animate.min.css', null, EVCA_PLUGIN::GET( 'Version' ) );
	}

	protected function scripts(){
		wp_enqueue_script( 'evca-animation', EVCA_ASSETS . 'vendors/animations/animate.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
	}

	protected function map(){
		return array(
			'name'            => esc_html_x( 'Animation', 'EVCA Animation', 'thrump-vc-addon' ),
			'description'     => esc_html_x( 'Add animations to elements', 'EVCA Animation', 'thrump-vc-addon' ),
			'content_element' => true,
			'js_view'         => 'VcColumnView',
			'as_parent'       => array(
				'except' => $this->shortcode,
			),
			'params'          => array(
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'CSS Animation', 'EVCA Animation', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select the type of animation you want this element to be animated with when it enteres in the browsers viewport', 'EVCA Animation', 'thrump-vc-addon' ),
					'param_name'  => 'effect',
					'value'       => $this->effects,
					'std'         => key( $this->effects ),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Animation delay', 'EVCA Animation', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Use this to delay the animation for a few (mili)seconds. Value in milliseconds, default 0', 'EVCA Animation', 'thrump-vc-addon' ),
					'param_name'  => 'delay',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Animation Duration', 'EVCA Animation', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Use this to specify the amount of time the animation should play. Value in milliseconds, default 1000', 'EVCA Animation', 'thrump-vc-addon' ),
					'param_name'  => 'speed',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Offset', 'EVCA Animation', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Add an animation offset. Value in percentages, default 90%', 'EVCA Animation', 'thrump-vc-addon' ),
					'param_name'  => 'offset',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Animation', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Animation', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCodesContainer' ) ){
	class WPBakeryShortCode_evca_animation extends WPBakeryShortCodesContainer {}
}

new EVCA_Animation;
