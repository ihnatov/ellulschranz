<?php
/**
 * EDNS VISUAL COMPOSER Image Dropdown Param
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Image_Select extends EVCA_Param {

	public function render( $settings, $value ){
		$settings = wp_parse_args( $settings, array(
			'param_name' => '',
			'type'       => '',
			'value'      => array(),
			'class'      => '',
		) );
		$class  = EVCA_PLUGIN::FILTER_CLASS( $settings['class'], array(
			'evca-image-value',
			'wpb_vc_param_value',
			$settings['param_name'],
			$settings['type'] . '_field',
		) );
		$output = '<div class="evca-image-select">';
		if( is_array( $settings['value'] ) ){
			foreach( $settings['value'] as $img => $val ){
				$output.= sprintf(
					'<label%5$s>
						<img src="%1$s" alt="%3$s"/>
						<input type="radio" name="evca-image-select-%2$s" class="evca-image-option" value="%3$s"%4$s/>
					</label>',
					esc_attr( $img ), esc_attr( $settings['param_name'] ),
					esc_attr( $val ), checked( $val, $value ), ( $val == $value ? ' class="active"' : '' )
				);
			}
		}
		$output.= sprintf(
			'<input type="hidden" name="%1$s" class="%2$s" value="%3$s"/>',
			esc_attr( $settings['param_name'] ), esc_attr( $class ), esc_attr( $value )
		);
		$output.= '</div>';
		return $output;
	}

	protected function script(){
		return EVCA_ASSETS . 'js/params/evca_image_select.js';
	}

}

new EVCA_Image_Select;
