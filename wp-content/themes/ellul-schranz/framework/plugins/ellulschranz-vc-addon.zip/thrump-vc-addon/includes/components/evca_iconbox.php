<?php
/**
 * EDNS VISUAL COMPOSER Icon Box Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_IconBox extends EVCA_Shortcode {

	protected $style = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title' => '',
			'style' => '',
			'icon'  => '',
			'link'  => '',
			'more'  => false,
			'class' => '',
		), $atts );
		$atts['style'] = in_array( $atts['style'], $this->style ) ? $atts['style'] : $this->style[ key( $this->style ) ];
		$atts['class'] = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( $atts['style'] ) );
		$atts['link']  = EVCA_PLUGIN::FILTER_LINK( $atts['link'] );
		$atts['more']  = $atts['more'] == 'true' ? true : false;
		switch( $atts['style'] ){
			case 'icon-box-2':
				$heading = '<h3>%s</h3>';
				break;
			case 'icon-box-4':
				$heading = '<h6>%s</h6>';
				break;
			default:
				$heading = '<h4>%s</h4>';
		}
		$output = sprintf( '<div class="%s">', esc_attr( $atts['class'] ) );
			// indented code view
			if( ! empty( $atts['icon'] ) && in_array( $atts['style'], array( 'icon-box-1', 'icon-box-2', 'icon-box-3' ) ) ){
				$output.= sprintf( '<i class="%s"></i>', esc_attr( $atts['icon'] ) );
			}
			$output.= '<div class="icon-box-content">';
			$more   = '';
			if( ! empty( $atts['link']['url'] ) ){
				$more = sprintf(
					'<a href="%s" target="%s">%s</a>',
					esc_url( $atts['link']['url'] ),
					esc_attr( $atts['link']['target'] ),
					esc_html( $atts['title'] )
				);
			} else {
				$more = esc_html( $atts['title'] );
			}
			$output.= sprintf( $heading, $more );
			$output.= wpautop( $content, true );
			if( $atts['more'] && ! empty( $atts['link']['url'] ) ){
				$output.= sprintf(
					'<a href="%s" target="%s">%s</a>',
					esc_url( $atts['link']['url'] ),
					esc_attr( $atts['link']['target'] ),
					esc_html( $atts['link']['title'] )
				);
			}
			$output.= '</div>';
		$output.= '</div>';
		return $output;
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Icon Box', 'EVCA Icon Box', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Add boxed content with icon', 'EVCA Boxes', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'       => 'evca_image_select',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Iconbox Style', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'param_name' => 'style',
					'value'      => $this->style,
					'std'        => $this->style[ key( $this->style ) ],
				),
				array(
					'type'        => 'iconpicker',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Icon', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select icon from library.', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'param_name'  => 'icon',
					'settings'    => array(
						'emptyIcon'    => true,
						'type'         => 'icon-font-custom',
						'iconsPerPage' => 200,
					),
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'icon-box-1', 'icon-box-2', 'icon-box-3' ),
					),
				),
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Title', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'param_name' => 'title',
				),
				array(
					'type'        => 'textarea_html',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Content', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Add description text for the service', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'param_name'  => 'content',
				),
				array(
					'type'        => 'vc_link',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Link (Optional)', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify an optional link to another page', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'param_name'  => 'link',
				),
				array(
					'type'        => 'checkbox',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Show read more', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Title will be inherited from Link Title', 'EVCA Icon Box', 'thrump-vc-addon' ),
					'param_name'  => 'more',
					'dependency'  => array(
						'element'   => 'link',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->style = array(
			EVCA_ASSETS . 'images/iconbox-1.png' => 'icon-box-1',
			EVCA_ASSETS . 'images/iconbox-2.png' => 'icon-box-2',
			EVCA_ASSETS . 'images/iconbox-3.png' => 'icon-box-3',
			EVCA_ASSETS . 'images/iconbox-4.png' => 'icon-box-4',
			EVCA_ASSETS . 'images/iconbox-5.png' => 'icon-box-5',
			EVCA_ASSETS . 'images/iconbox-6.png' => 'icon-box-6',
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_iconbox extends WPBakeryShortCode {}
}

new EVCA_IconBox;
