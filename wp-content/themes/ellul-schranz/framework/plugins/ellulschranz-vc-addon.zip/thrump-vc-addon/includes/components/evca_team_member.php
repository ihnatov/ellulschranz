<?php
/**
 * EDNS VISUAL COMPOSER Team Member Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Team_Member extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'name'        => '',
			'position'    => '',
			'text'        => '',
			'image'       => '',
			'img_size'    => '',
			'custom_size' => '',
			'class'       => '',
		), $atts );
		$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'team-member' ) );
		$atts['img_size'] = in_array( $atts['img_size'], $this->image_sizes ) ? $atts['img_size'] : $this->image_sizes[ key( $this->image_sizes ) ];
		$atts['image']    = absint( $atts['image'] );
		$output           = '';
		if( $atts['image'] ){
			$atts['custom_size'] = strtolower( $atts['custom_size'] );
			if( 'evca-custom-image-size' === $atts['img_size'] && strpos( $atts['custom_size'], 'x' ) !== false ){
				$size = explode( 'x', $atts['custom_size'] );
				if( isset( $size[0], $size[1] ) ){
					$image_size = array_map( 'absint', $size );
				}
			} else {
				$image_size = $atts['img_size'];
			}
			$output.= wp_get_attachment_image( $atts['image'], $image_size );
		}
		if( ! empty( $atts['name'] ) ){
			$output.= sprintf( '<h4>%s</h4>', esc_html( $atts['name'] ) );
		}
		if( ! empty( $atts['position'] ) ){
			$output.= sprintf( '<h6>%s</h6>', esc_html( $atts['position'] ) );
		}
		if( ! empty( $atts['text'] ) ){
			$output.= wpautop( $atts['text'], true );
		}
		if( ! empty( $content ) ){
			$output.= sprintf( '<div class="social-media">%s</div>', do_shortcode( $content ) );
		}
		return sprintf( '<div class="%s">%s</div>', esc_attr( $class ), $output );
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Team Member', 'EVCA Team Member', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Add info about an employee', 'EVCA Team Member', 'thrump-vc-addon' ),
			'as_parent'   => array(
				'only' => 'evca_social',
			),
			'js_view'     => 'VcColumnView',
			'params'      => array(
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Person name', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name' => 'name',
				),
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Occupied position ( Optional )', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name' => 'position',
				),
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Description ( Optional )', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name' => 'text',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Team Member', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
				array(
					'type'        => 'attach_image',
					'group'       => esc_html_x( 'Image', 'EVCA Team Member', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image', 'EVCA Team Member', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select image from media library.', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name'  => 'image',
				),
				array(
					'type'        => 'dropdown',
					'group'       => esc_html_x( 'Image', 'EVCA Team Member', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image size', 'EVCA Team Member', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select image size.', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name'  => 'img_size',
					'value'       => $this->image_sizes,
					'std'         => $this->image_sizes[ key( $this->image_sizes ) ],
					'dependency'  => array(
						'element'   => 'image',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'group'       => esc_html_x( 'Image', 'EVCA Team Member', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Custom image size', 'EVCA Team Member', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Custom image size proportional to original images size. Ex: 640x480 -> 320x240 [ Width x Height ]', 'EVCA Team Member', 'thrump-vc-addon' ),
					'param_name'  => 'custom_size',
					'dependency'  => array(
						'element' => 'img_size',
						'value'   => 'evca-custom-image-size',
					),
				),
			),
		);
	}

	protected function pre_register(){
		$this->load_image_sizes();
	}

}

if( class_exists( 'WPBakeryShortCodesContainer' ) ){
	class WPBakeryShortCode_evca_team_member extends WPBakeryShortCodesContainer {}
}

new EVCA_Team_Member;
