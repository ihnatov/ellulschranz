<?php
/**
 * EDNS VISUAL COMPOSER Service Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Service extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'class' => '',
		), $atts );
		$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'] );
		return sprintf( '<li class="%s">%s</li>', esc_attr( $class ), do_shortcode( $content ) );
	}

	protected function map(){
		return array(
			'name'                    => esc_html_x( 'Service', 'EVCA Service', 'thrump-vc-addon' ),
			'description'             => esc_html_x( 'Add new service', 'EVCA Service', 'thrump-vc-addon' ),
			'as_child'                => array(
				'only'   => 'evca_service_list',
			),
			'as_parent'               => array(
				'except' => 'evca_service_list,evca_service',
			),
			'show_settings_on_create' => false,
			'js_view'                 => 'VcColumnView',
			'params'                  => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Service', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Service', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

class EVCA_Service_List extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'class' => '',
		), $atts );
		$class   = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'services-list' ) );
		return sprintf( '<ul class="%s">%s</ul>', esc_attr( $class ), do_shortcode( $content ) );
	}

	protected function map(){
		return array(
			'name'                    => esc_html_x( 'Service List', 'EVCA Service', 'thrump-vc-addon' ),
			'description'             => esc_html_x( 'Add your services', 'EVCA Service', 'thrump-vc-addon' ),
			'as_parent'               => array(
				'only' => 'evca_service',
			),
			'show_settings_on_create' => false,
			'js_view'                 => 'VcColumnView',
			'params'                  => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Service', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Service', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCodesContainer' ) ){
	class WPBakeryShortCode_evca_service_list extends WPBakeryShortCodesContainer {}
}

if( class_exists( 'WPBakeryShortCodesContainer' ) ){
	class WPBakeryShortCode_evca_service extends WPBakeryShortCodesContainer {}
}

new EVCA_Service_List;

new EVCA_Service;
