<?php
/**
 * EDNS VISUAL COMPOSER Countdown Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Countdown extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'date'  => '',
			'class' => '',
		), $atts );
		if( ! empty( $atts['date'] ) ){
			$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'evca-countdown', 'text-center' ) );
			return sprintf( '<div class="%s" data-countdown="%s"></div>%s', esc_attr( $class ), esc_attr( $atts['date'] ), do_shortcode( $content ) );
		}
	}

	protected function scripts(){
		wp_enqueue_script( 'jquery-countdown-jq', EVCA_ASSETS . 'vendors/countdown/jquery.plugin.min.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
		wp_enqueue_script( 'jquery-countdown', EVCA_ASSETS . 'vendors/countdown/jquery.countdown.min.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
		wp_localize_script( 'jquery-countdown', 'evca_countdown', array(
			'labels'        => array(
				esc_html_x( 'Years', 'EVCA Countdown plural', 'thrump-vc-addon' ),
				esc_html_x( 'Months', 'EVCA Countdown plural', 'thrump-vc-addon' ),
				esc_html_x( 'Weeks', 'EVCA Countdown plural', 'thrump-vc-addon' ),
				esc_html_x( 'Days', 'EVCA Countdown plural', 'thrump-vc-addon' ),
				esc_html_x( 'Hours', 'EVCA Countdown plural', 'thrump-vc-addon' ),
				esc_html_x( 'Minutes', 'EVCA Countdown plural', 'thrump-vc-addon' ),
				esc_html_x( 'Seconds', 'EVCA Countdown plural', 'thrump-vc-addon' ),
			),
			'labels1'       => array(
				esc_html_x( 'Year', 'EVCA Countdown singular', 'thrump-vc-addon' ),
				esc_html_x( 'Month', 'EVCA Countdown singular', 'thrump-vc-addon' ),
				esc_html_x( 'Week', 'EVCA Countdown singular', 'thrump-vc-addon' ),
				esc_html_x( 'Day', 'EVCA Countdown singular', 'thrump-vc-addon' ),
				esc_html_x( 'Hour', 'EVCA Countdown singular', 'thrump-vc-addon' ),
				esc_html_x( 'Minute', 'EVCA Countdown singular', 'thrump-vc-addon' ),
				esc_html_x( 'Second', 'EVCA Countdown singular', 'thrump-vc-addon' ),
			),
			'compactLabels' => array(
				esc_html_x( 'y', 'EVCA Countdown compact label Year', 'thrump-vc-addon' ),
				esc_html_x( 'm', 'EVCA Countdown compact label Month', 'thrump-vc-addon' ),
				esc_html_x( 'w', 'EVCA Countdown compact label Week', 'thrump-vc-addon' ),
				esc_html_x( 'd', 'EVCA Countdown compact label Day', 'thrump-vc-addon' ),
			),
			'digits'        => array(
				esc_html_x( '0', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '1', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '2', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '3', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '4', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '5', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '6', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '7', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '8', 'EVCA Countdown digit', 'thrump-vc-addon' ),
				esc_html_x( '9', 'EVCA Countdown digit', 'thrump-vc-addon' ),
			),
			'timeSeparator' => esc_html_x( ':', 'EVCA Countdown separator', 'thrump-vc-addon' ),
			'whichLabels'   => null,
			'isRTL'         => is_rtl(),
		) );
	}

	protected function map(){
		return array(
			'name'   => esc_html_x( 'Countdown', 'EVCA Countdown', 'thrump-vc-addon' ),
			'params' => array(
				array(
					'type'        => 'evca_datepicker',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Countdown date', 'EVCA Countdown', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the date from which to start the countdown in the format of yyyy-mm-dd ( year-month-day )', 'EVCA Countdown', 'thrump-vc-addon' ),
					'param_name'  => 'date',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Countdown', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Countdown', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_countdown extends WPBakeryShortCode {}
}

new EVCA_Countdown;
