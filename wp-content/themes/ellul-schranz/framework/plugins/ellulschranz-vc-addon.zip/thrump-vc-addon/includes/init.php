<?php
/**
 * EDNS VISUAL COMPOSER Init File
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Manager {

	public function __construct(){
		add_filter( 'vc_load_default_templates', array( $this, 'remove_default_templates' ) );
		add_action( 'init', array( $this, 'add_params' ), 999 );
		add_action( 'init', array( $this, 'add_components' ), 999 );
		add_action( 'wp_footer', array( $this, 'wp_footer' ), 999 );
	}

	public function remove_default_templates(){
		return array();
	}

	public function add_params(){
		$files = glob( EVCA_INCLUDES . '/params/*.php', GLOB_NOSORT );
		if( $files ){
			foreach( $files as $file ){
				include_once $file;
			}
		}
	}

	public function add_components(){
		$files = glob( EVCA_INCLUDES . '/components/*.php', GLOB_NOSORT );
		if( $files ){
			foreach( $files as $file ){
				include_once $file;
			}
		}
	}

	public function wp_footer(){
		/******************************
		 * Unminified
		 *****************************/
		/* ?>
		<script type="text/javascript">
		(function($){
			function vc_resize(){
				var $elements = $('[data-vc-full-width="true"]');
				$.each( $elements, function( key, item ){
					var $el = $(this);
					$el.addClass('vc_hidden');
					var $el_full = $el.next('.vc_row-full-width');
					$el_full.length || ($el_full = $el.parent().next('.vc_row-full-width'));
					var el_margin_left = parseFloat( $el.css('margin-left') ),
						el_margin_right = parseFloat( $el.css('margin-right') ),
						offset = $('#wrap').offset().left - $el_full.offset().left - el_margin_left,
						width = $('#wrap').width();
					$el.css({
						position: 'relative',
						left: offset,
						'box-sizing': 'border-box',
						width: $('#wrap').width()
					});
					if( ! $el.data('vcStretchContent') ){
						var padding = -1 * offset;
						if( 0 > padding ) padding = 0;
						var paddingRight = width - padding - $el_full.width() + el_margin_left + el_margin_right;
						if( 0 > paddingRight ) paddingRight = 0;
						$el.css({
							'padding-left': padding,
							'padding-right': paddingRight
						});
					}
					$el.attr('data-vc-full-width-init', 'true');
					$el.removeClass('vc_hidden');
				});
				$('.vc_row-o-full-height:first').each(function(){
					var $window, windowHeight, offsetTop, fullHeight;
					$window = $(window), windowHeight = $window.height(), offsetTop = $(this).offset().top, windowHeight > offsetTop && (fullHeight = 100 - offsetTop / (windowHeight / 100), $(this).css('min-height', fullHeight + 'vh'))
				})
			}
			var $vc_rowBehaviour = window.vc_rowBehaviour;
			window.vc_rowBehaviour = function(){
				$vc_rowBehaviour();
				if( $('body').hasClass('boxed-layout') ){
					$(window).off('resize.vcRowBehaviour').on('resize.vcRowBehaviour',vc_resize);
					vc_resize();
				}
			};
		})(jQuery);
		</script>
		<?php */
		/******************************
		 * Minified
		 *****************************/
		echo '<script type="text/javascript">!function(t){function i(){var i=t(\'[data-vc-full-width="true"]\');t.each(i,function(i,a){var e=t(this);e.addClass("vc_hidden");var o=e.next(".vc_row-full-width");o.length||(o=e.parent().next(".vc_row-full-width"));var r=parseFloat(e.css("margin-left")),h=parseFloat(e.css("margin-right")),n=t("#wrap").offset().left-o.offset().left-r,s=t("#wrap").width();if(e.css({position:"relative",left:n,"box-sizing":"border-box",width:t("#wrap").width()}),!e.data("vcStretchContent")){var d=-1*n;0>d&&(d=0);var v=s-d-o.width()+r+h;0>v&&(v=0),e.css({"padding-left":d,"padding-right":v})}e.attr("data-vc-full-width-init","true"),e.removeClass("vc_hidden")}),t(".vc_row-o-full-height:first").each(function(){var i,a,e,o;i=t(window),a=i.height(),e=t(this).offset().top,a>e&&(o=100-e/(a/100),t(this).css("min-height",o+"vh"))})}var a=window.vc_rowBehaviour;window.vc_rowBehaviour=function(){a(),t("body").hasClass("boxed-layout")&&(t(window).off("resize.vcRowBehaviour").on("resize.vcRowBehaviour",i),i())}}(jQuery);</script>';
	}

}

abstract class EVCA_Shortcode {

	protected		$shortcode,
					$load_dependecies = false,
					$image_sizes      = array();

	public static	$loaded_main_js   = false,
					$loaded_main_css  = false;

	public function __construct(){
		$this->shortcode = strtolower( get_class( $this ) );
		$this->pre_register();
		$this->register();
		$this->register_styles();
		$this->register_scripts();
	}

	private function register(){
		add_shortcode( $this->shortcode, array( $this, 'render_wrap' ) );
		$component = $this->map();
		if( function_exists( 'vc_map' ) && is_array( $component ) ){
			$component['base']     = $this->shortcode;
			$component['category'] = esc_html__( 'Thrump Elements', 'thrump-vc-addon' );
			$component['icon']     = EVCA_ASSETS . 'images/component-icon.png';
			vc_map( $component );
		}
	}

	private function register_scripts(){
		add_action( 'wp_footer', array( $this, 'load_scripts' ), 0 );
		add_action( 'wp_footer', array( $this, 'load_main_js' ), 1 );
	}

	private function register_styles(){
		add_action( 'wp_enqueue_scripts', array( $this, 'load_main_style' ), 11 );
		add_action( 'wp_enqueue_scripts', array( $this, 'load_styles' ), 9 );
		add_action( 'vc_backend_editor_enqueue_js_css', array( $this, 'composer_css' ) );
		add_action( 'vc_frontend_editor_enqueue_js_css', array( $this, 'composer_css' ) );
	}

	public function load_main_style(){
		if( ! self::$loaded_main_css ){
			self::$loaded_main_css = true;
			wp_enqueue_style( 'evca-components', EVCA_ASSETS . 'css/components.css', null, EVCA_PLUGIN::GET( 'Version' ) );
		}
	}

	public function load_styles(){
		$this->styles();
	}

	public function composer_css(){
		wp_enqueue_style( 'evca-js-composer', EVCA_ASSETS . 'css/composer.css', null, EVCA_PLUGIN::GET( 'Version' ) );
	}

	public function load_main_js(){
		if( $this->load_dependecies && ! self::$loaded_main_js ){
			self::$loaded_main_js = true;
			wp_enqueue_script( 'jquery-viewport', EVCA_ASSETS . 'vendors/viewport/jquery.viewport.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
			wp_enqueue_script( 'evca-components', EVCA_ASSETS . 'js/components.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
		}
	}

	public function load_scripts(){
		if( $this->load_dependecies ){
			$this->scripts();
		}
	}

	public function render_wrap( $atts, $content = null ){
		$this->load_dependecies = true;
		return $this->render( $atts, $content );
	}

	protected function load_image_sizes(){
		global $_wp_additional_image_sizes;
		$tmp = get_intermediate_image_sizes();
		foreach( $tmp as $_size ){
			if( in_array( $_size, array( 'thumbnail', 'medium', 'medium_large', 'large' ) ) ){
				$this->image_sizes[ sprintf(
					'%s [ %sx%s%s ]',
					esc_html( $_size ), get_option( "{$_size}_size_w" ), get_option( "{$_size}_size_h" ),
					( (bool) get_option( "{$_size}_crop" ) ? esc_html_x( ' | cropped', 'EVCA Image Size', 'thrump-vc-addon' ) : '' )
				) ] = $_size;
			} elseif ( isset( $_wp_additional_image_sizes[ $_size ] ) ) {
				$this->image_sizes[ sprintf(
					'%s [ %sx%s%s ]',
					esc_html( $_size ), $_wp_additional_image_sizes[ $_size ]['width'], $_wp_additional_image_sizes[ $_size ]['height'],
					( $_wp_additional_image_sizes[ $_size ]['crop'] ? esc_html_x( ' | cropped', 'EVCA Image Size', 'thrump-vc-addon' ) : '' )
				) ] = $_size;
			}
		}
		$this->image_sizes[
			esc_html_x( 'Full size image [ Original Width x Original Height ]', 'EVCA Image Size', 'thrump-vc-addon' )
		] = 'full';
		$this->image_sizes[
			esc_html_x( '-- Custom --', 'EVCA Image Size', 'thrump-vc-addon' )
		] = 'evca-custom-image-size';
	}

	protected function render( $atts, $content = null ){}
	protected function pre_register(){}
	protected function scripts(){}
	protected function styles(){}
	protected function map(){}

}

abstract class EVCA_Param {

	protected $param_name,
			  $script_url;

	public function __construct(){
		$this->param_name = strtolower( get_class( $this ) );
		$this->script_url = $this->script();
		$this->pre_register();
		$this->register();
	}

	private function register(){
		if( function_exists( 'vc_add_shortcode_param' ) ){
			vc_add_shortcode_param( $this->param_name, array( $this, 'render' ), $this->script_url );
		}
	}

	public function render( $settings, $value ){}

	protected function pre_register(){}
	protected function script(){}

}

new EVCA_Manager;
