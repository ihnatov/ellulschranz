<?php
/**
 * EDNS VISUAL COMPOSER Image Box Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_ImageBox extends EVCA_Shortcode {

	private $align = array(),
			$style = array();

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'title'         => '',
			'style'         => '',
			'link'          => '',
			'icon'          => '',
			'more'          => false,
			'image'         => '',
			'img_size'      => '',
			'custom_size'   => '',
			'border_radius' => '',
			'class'         => '',
		), $atts );
		$atts['img_size'] = in_array( $atts['img_size'], $this->image_sizes ) ? $atts['img_size'] : $this->image_sizes[ key( $this->image_sizes ) ];
		$atts['link']     = EVCA_PLUGIN::FILTER_LINK( $atts['link'] );
		$atts['image']    = absint( $atts['image'] );
		$default_classes  = array( 'image-box' );
		switch( $atts['style'] ){
			case 'imagebox-2': $default_classes[] = 'alt'; break;
			case 'imagebox-3': $default_classes[] = 'alt-2'; break;
		}
		$atts['class']    = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], $default_classes );
		$output = sprintf( '<div class="%s">', esc_attr( $atts['class'] ) );
		$icon   = '';
		if( ! empty( $atts['icon'] ) && in_array( $atts['style'], array( 'imagebox-2', 'imagebox-3' ) ) ){
			$icon = sprintf( '<i class="%s"></i>', esc_attr( $atts['icon'] ) );
		}
		$image  = '';
		if( $atts['image'] ){
			$atts['custom_size'] = strtolower( $atts['custom_size'] );
			if( 'evca-custom-image-size' === $atts['img_size'] && strpos( $atts['custom_size'], 'x' ) !== false ){
				$size = explode( 'x', $atts['custom_size'] );
				if( isset( $size[0], $size[1] ) ){
					$image_size = array_map( 'absint', $size );
				}
			} else {
				$image_size = $atts['img_size'];
			}
			$img_attr = array();
			if( ! empty( $atts['border_radius'] ) ){
				$img_attr['style'] = sprintf(
					'border-radius:%s',
					esc_attr( EVCA_PLUGIN::FILTER_BORDER_RADIUS( $atts['border_radius'] ) )
				);
			}
			$image  = wp_get_attachment_image( $atts['image'], $image_size, false, $img_attr );
			if( ! empty( $atts['link']['url'] ) ){
				$image = sprintf(
					'<a href="%s" target="%s">%s</a>',
					esc_url( $atts['link']['url'] ),
					esc_attr( $atts['link']['target'] ),
					$image
				);
			}
		}
		$align = '';
		switch( $atts['style'] ){
			case 'imagebox-2':
				$output.= sprintf( '%s<div class="image-box-img">%s</div>', $icon, $image );
				break;
			case 'imagebox-3':
				$output.= sprintf( '<div class="image-box-img">%s%s</div>', $icon, $image );
				$align  = 'center';
				break;
			default:
				$output.= sprintf( '<div class="image-box-img">%s</div>', $image );
		}
		$headline = EVCA_PLUGIN::FILTER_CLASS( '', array( 'headline', $align ) );
		$output.= '<div class="' . esc_attr( $headline ) . '"><h3>';
		if( ! empty( $atts['link']['url'] ) ){
			$output.= sprintf(
				'<a href="%s" target="%s">%s</a>',
				esc_url( $atts['link']['url'] ),
				esc_attr( $atts['link']['target'] ),
				esc_html( $atts['title'] )
			);
		} else {
			$output.= esc_html( $atts['title'] );
		}
		$output.= '</h3></div>';
		$output.= wpautop( $content, true );
		if( $atts['more'] && ! empty( $atts['link']['url'] ) ){
			$output.= sprintf(
				'<a href="%s" class="btn" target="%s">%s</a>',
				esc_url( $atts['link']['url'] ),
				esc_attr( $atts['link']['target'] ),
				esc_html( $atts['link']['title'] )
			);
		}
		$output.= '</div>';
		return $output;
	}

	protected function map(){
		return array(
 			'name'        => esc_html_x( 'Image Box', 'EVCA Image Box', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Add boxed content with image', 'EVCA Image Box', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'       => 'evca_image_select',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Imagebox Style', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name' => 'style',
					'value'      => $this->style,
					'std'        => $this->style[ key( $this->style ) ],
				),
				array(
					'type'        => 'iconpicker',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Icon', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select icon from library.', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'icon',
					'settings'    => array(
						'emptyIcon'    => true,
						'type'         => 'icon-font-custom',
						'iconsPerPage' => 200,
					),
					'dependency'  => array(
						'element' => 'style',
						'value'   => array( 'imagebox-2', 'imagebox-3' ),
					),
				),
				array(
					'type'        => 'textfield',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Title', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the text of the headline', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'title',
				),
				array(
					'type'        => 'textarea_html',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Content', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Add description text for the service', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'content',
				),
				array(
					'type'        => 'vc_link',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Link (Optional)', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify an optional link to another page', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'link',
				),
				array(
					'type'        => 'checkbox',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Show read more', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Title will be inherited from Link Title', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'more',
					'dependency'  => array(
						'element'   => 'link',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
				array(
					'type'        => 'attach_image',
					'group'       => esc_html_x( 'Image', 'EVCA Image Box', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select image from media library.', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'image',
				),
				array(
					'type'        => 'dropdown',
					'group'       => esc_html_x( 'Image', 'EVCA Image Box', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image size', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select image size.', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'img_size',
					'value'       => $this->image_sizes,
					'std'         => $this->image_sizes[ key( $this->image_sizes ) ],
					'dependency'  => array(
						'element'   => 'image',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'group'       => esc_html_x( 'Image', 'EVCA Image Box', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Custom image size', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Custom image size proportional to original images size. Ex: 640x480 -> 320x240 [ Width x Height ]', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'custom_size',
					'dependency'  => array(
						'element' => 'img_size',
						'value'   => 'evca-custom-image-size',
					),
				),
				array(
					'type'        => 'textfield',
					'group'       => esc_html_x( 'Image', 'EVCA Image Box', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image border radius', 'EVCA Image Box', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Custom border radius of the selected image. Syntax needs to be defined according to the CSS border-radius property. Units: em, ex, ch, rem, vw, vh, vmin, vmax, %, cm, mm, in, px, pt, pc', 'EVCA Image Box', 'thrump-vc-addon' ),
					'param_name'  => 'border_radius',
					'dependency'  => array(
						'element'   => 'image',
						'not_empty' => true,
					),
				),
			),
		);
	}

	protected function pre_register(){
		$this->load_image_sizes();
		$this->style = array(
			EVCA_ASSETS . 'images/imagebox-1.jpg' => 'imagebox-1',
			EVCA_ASSETS . 'images/imagebox-2.jpg' => 'imagebox-2',
			EVCA_ASSETS . 'images/imagebox-3.jpg' => 'imagebox-3',
		);
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_imagebox extends WPBakeryShortCode {}
}

new EVCA_ImageBox;
