<?php
/**
 * EDNS VISUAL COMPOSER Datepicker Param
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Datepicker extends EVCA_Param {

	public function render( $settings, $value ){
		$settings = wp_parse_args( $settings, array(
			'param_name' => '',
			'type'       => '',
			'class'      => '',
		) );
		$class  = EVCA_PLUGIN::FILTER_CLASS( $settings['class'], array(
			'evca-datepicker',
			'wpb_vc_param_value',
			'wpb-textinput',
			$settings['param_name'],
			$settings['type'] . '_field',
		) );
		return sprintf(
			'<input type="date" name="%1$s" class="%2$s" value="%3$s"/>',
			esc_attr( $settings['param_name'] ), esc_attr( $class ), esc_attr( $value )
		);
	}

	protected function script(){
		return EVCA_ASSETS . 'js/params/evca_datepicker.js';
	}

	protected function pre_register(){
		add_action( 'vc_backend_editor_enqueue_js_css', array( $this, 'enqueue_date_picker' ) );
		add_action( 'vc_frontend_editor_enqueue_js_css', array( $this, 'enqueue_date_picker' ) );
	}

	public function enqueue_date_picker(){
		wp_enqueue_style( 'jquery-ui', EVCA_ASSETS . 'vendors/jquery-ui-datepicker/jquery-ui.min.css' );
		wp_enqueue_script( 'jquery-ui-datepicker' );
		wp_localize_script( 'jquery-ui-datepicker', 'evca_datepicker', array(
			'firstDay'   => get_option( 'start_of_week' ),
			'dateFormat' => 'yy-mm-dd',
		) );
	}

}

new EVCA_Datepicker;
