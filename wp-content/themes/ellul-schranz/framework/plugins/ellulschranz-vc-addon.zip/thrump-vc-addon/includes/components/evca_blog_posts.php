<?php
/**
 * EDNS VISUAL COMPOSER Blog Posts Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Blog_Posts extends EVCA_Shortcode {

	protected $post_types = array(),
			  $columns    = array();

	protected function render( $atts, $content = '' ){
		$atts   = shortcode_atts( array(
			'post_type' => '',
			'max_items' => '',
			'cols'      => 1,
			'class'     => '',
		), $atts );
		$span   = round(
			12 /
			( $columns = absint(
					in_array( $atts['cols'], $this->columns )
						? $atts['cols']
						: $this->columns[ key( $this->columns ) ]
				)
			)
		);
		$output = '';
		$args   = array(
			'post_status'         => 'publish',
			'no_found_rows'       => true,
			'ignore_sticky_posts' => true,
		);
		if( ! empty( $atts['post_type'] ) ){
			$post_types        = explode( ',', $atts['post_type'] );
			$args['post_type'] = array();
			foreach( $post_types as $post_type ){
				if( in_array( $atts['post_type'], $this->post_types ) ){
					$args['post_type'][] = $post_type;
				}
			}
		}
		$args['posts_per_page'] = $atts['max_items'] >= -1 && $atts['max_items'] <= 999 ? intval( $atts['max_items'] ) : 10;
		$r = new WP_Query( $args );
		if( $r->have_posts() ){
			$i = 0;
			while( $r->have_posts() ) : $r->the_post();
				if( ( $i % $columns ) === 0 ){
					$output.= '</div><div class="row">';
				}
				$post_class = str_replace( ' has-post-thumbnail', '', EVCA_PLUGIN::FILTER_CLASS(
					$atts['class'], array_merge( array( 'alt' ), get_post_class() )
				) );
				$output    .= sprintf(
					'<div class="span%1$u">
                        <div class="%2$s">
                        	<span class="posted-on">%3$s</span>
							<div class="post-header">
                                <span class="cat-links">%4$s</span>
								<h5 class="post-title">
									<a rel="bookmark" href="%5$s">%6$s</a>
								</h5>
							</div>
							<div class="post-content">
								<p>%7$s</p>
								<p>
                                	<a class="more-link" href="%5$s">%8$s</a>
                                </p>
							</div>
						</div>
					</div>',
					$span, $post_class, get_the_date(), get_the_category_list( ' | ' ),
					get_the_permalink(), ( get_the_title() ? get_the_title() : get_the_ID() ),
					get_the_excerpt(), esc_html_x( 'Read more', 'EVCA Blog Posts', 'edns-vc-addon' )
				);
				$i++;
			endwhile;
			wp_reset_postdata();
		}
		return sprintf( '<div class="row">%s</div>', $output );
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Blog Posts', 'EVCA Blog Posts', 'edns-vc-addon' ),
			'description' => esc_html_x( 'List recent posts', 'EVCA Blog Posts', 'edns-vc-addon' ),
			'params'      => array(
				array(
					'type'        => 'posttypes',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Post types', 'EVCA Blog Posts', 'edns-vc-addon' ),
					'description' => esc_html_x( 'Select the post types you want to display', 'EVCA Blog Posts', 'edns-vc-addon' ),
					'param_name'  => 'post_type',
				),
				array(
					'type'        => 'dropdown',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Columns', 'EVCA Blog Posts', 'edns-vc-addon' ),
					'description' => esc_html_x( 'Select the number of columns', 'EVCA Blog Posts', 'edns-vc-addon' ),
					'param_name'  => 'cols',
					'value'       => $this->columns,
					'std'         => $this->columns[ key( $this->columns ) ],
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Total items', 'js_composer' ),
					'description' => esc_html_x( 'Specify the max limit for items between -1 ( all ) and 999.', 'js_composer' ),
					'param_name'  => 'max_items',
					'value'       => 10,
					'dependency'  => array(
						'element'   => 'post_type',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Blog Posts', 'edns-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Blog Posts', 'edns-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

	protected function pre_register(){
		$this->post_types = get_post_types( array(
			'public' => true,
		) );
		$this->columns    = array( 1, 2, 3, 4, 6 );
	}

}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_blog_posts extends WPBakeryShortCode {}
}

new EVCA_Blog_Posts;
