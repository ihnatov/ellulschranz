<?php
/**
 * EDNS VISUAL COMPOSER Testimonial Component
 *
 * @package EVCA
 */

if( ! defined( 'ABSPATH' ) ){ exit; }

class EVCA_Testimonial extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'name'          => '',
			'position'      => '',
			'testimonial'   => '',
			'image'         => '',
			'img_size'      => '',
			'custom_size'   => '',
			'border_radius' => '',
			'class'         => '',
		), $atts );
		$class            = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'testimonial' ) );
		$atts['img_size'] = in_array( $atts['img_size'], $this->image_sizes ) ? $atts['img_size'] : $this->image_sizes[ key( $this->image_sizes ) ];
		$atts['image']    = absint( $atts['image'] );
		$output           = sprintf(
			'<div class="%s">
				<blockquote>
					<p>%s</p>
				</blockquote>',
				esc_attr( $class ), wp_strip_all_tags( $atts['testimonial'] )
		);
		if( $atts['image'] ){
			$atts['custom_size'] = strtolower( $atts['custom_size'] );
			if( 'evca-custom-image-size' === $atts['img_size'] && strpos( $atts['custom_size'], 'x' ) !== false ){
				$size = explode( 'x', $atts['custom_size'] );
				if( isset( $size[0], $size[1] ) ){
					$image_size = array_map( 'absint', $size );
				}
			} else {
				$image_size = $atts['img_size'];
			}
			$img_attr = array();
			if( ! empty( $atts['border_radius'] ) ){
				$img_attr['style'] = sprintf(
					'border-radius:%s',
					esc_attr( EVCA_PLUGIN::FILTER_BORDER_RADIUS( $atts['border_radius'] ) )
				);
			}
			$output.= wp_get_attachment_image( $atts['image'], $image_size, false, $img_attr );
		}
		$output.= '<h4>';
		if( ! empty( $atts['name'] ) ){
			$output  .= sprintf( '%s, ', esc_html( $atts['name'] ) );
		}
		if( ! empty( $atts['position'] ) ){
			$output.= sprintf( '<span>%s</span>', esc_html( $atts['position'] ) );
		}
		$output.= '</h4>';
		$output.= '</div>';
		return $output;
	}

	protected function map(){
		return array(
			'name'        => esc_html_x( 'Testimonial', 'EVCA Testimonial', 'thrump-vc-addon' ),
			'description' => esc_html_x( 'Add a testimonial', 'EVCA Testimonial', 'thrump-vc-addon' ),
			'params'      => array(
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Company / person name', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name' => 'name',
				),
				array(
					'type'       => 'textfield',
					'holder'     => 'div',
					'heading'    => esc_html_x( 'Occupied position ( Optional )', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name' => 'position',
				),
				array(
					'type'        => 'textarea',
					'holder'      => 'div',
					'heading'     => esc_html_x( 'Testimonial', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Specify the text of the testimonial', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name'  => 'testimonial',
				),
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
				array(
					'type'        => 'attach_image',
					'group'       => esc_html_x( 'Image', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select image from media library.', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name'  => 'image',
				),
				array(
					'type'        => 'dropdown',
					'group'       => esc_html_x( 'Image', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image size', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Select image size.', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name'  => 'img_size',
					'value'       => $this->image_sizes,
					'std'         => $this->image_sizes[ key( $this->image_sizes ) ],
					'dependency'  => array(
						'element'   => 'image',
						'not_empty' => true,
					),
				),
				array(
					'type'        => 'textfield',
					'group'       => esc_html_x( 'Image', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Custom image size', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Custom image size proportional to original images size. Ex: 640x480 -> 320x240 [ Width x Height ]', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name'  => 'custom_size',
					'dependency'  => array(
						'element' => 'img_size',
						'value'   => 'evca-custom-image-size',
					),
				),
				array(
					'type'        => 'textfield',
					'group'       => esc_html_x( 'Image', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'heading'     => esc_html_x( 'Image border radius', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'Custom border radius of the selected image. Syntax needs to be defined according to the CSS border-radius property. Units: em, ex, ch, rem, vw, vh, vmin, vmax, %, cm, mm, in, px, pt, pc', 'EVCA Testimonial', 'thrump-vc-addon' ),
					'param_name'  => 'border_radius',
					'dependency'  => array(
						'element'   => 'image',
						'not_empty' => true,
					),
				),
			),
		);
	}

	protected function pre_register(){
		$this->load_image_sizes();
	}

}

class EVCA_Testimonial_Slider extends EVCA_Shortcode {

	protected function render( $atts, $content = '' ){
		$atts = shortcode_atts( array(
			'class' => '',
		), $atts );
		$class = EVCA_PLUGIN::FILTER_CLASS( $atts['class'], array( 'testimonial-slider-2' ) );
		return sprintf( '<div class="%s"><div class="slides">%s</div></div>', esc_attr( $class ), do_shortcode( $content ) );
	}

	protected function styles(){
		wp_enqueue_style( 'bxslider', EVCA_ASSETS . 'vendors/bxslider/jquery.bxslider.css', null, EVCA_PLUGIN::GET( 'Version' ) );
	}

	protected function scripts(){
		wp_enqueue_script( 'bxslider', EVCA_ASSETS . 'vendors/bxslider/jquery.bxslider.min.js', array( 'jquery' ), EVCA_PLUGIN::GET( 'Version' ), true );
	}

	protected function map(){
		return array(
			'name'                    => esc_html_x( 'Testimonial Slider', 'EVCA Testimonial Slider', 'thrump-vc-addon' ),
			'description'             => esc_html_x( 'Create a slider of testimonials', 'EVCA Testimonial Slider', 'thrump-vc-addon' ),
			'as_parent'               => array(
				'only' => 'evca_testimonial',
			),
			'show_settings_on_create' => false,
			'js_view'                 => 'VcColumnView',
			'params' => array(
				array(
					'type'        => 'textfield',
					'heading'     => esc_html_x( 'Extra class name', 'EVCA Testimonial Slider', 'thrump-vc-addon' ),
					'description' => esc_html_x( 'You can add multiple classes, separated by space', 'EVCA Testimonial Slider', 'thrump-vc-addon' ),
					'param_name'  => 'class',
				),
			),
		);
	}

}

if( class_exists( 'WPBakeryShortCodesContainer' ) ){
	class WPBakeryShortCode_evca_testimonial_slider extends WPBakeryShortCodesContainer {}
}

if( class_exists( 'WPBakeryShortCode' ) ){
	class WPBakeryShortCode_evca_testimonial extends WPBakeryShortCode {}
}

new EVCA_Testimonial_Slider;

new EVCA_Testimonial;
