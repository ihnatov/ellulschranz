<?php
/*
Plugin Name: Thrump VC Addon
Description: Visual Composer Addons
Author: Mujnoi Tamas @ EuropaDNS
Author URI: http://www.europadns.com
Version: 1.0.2
Text Domain: thrump-vc-addon
*/

if( ! defined( 'ABSPATH' ) ){ exit; }

/**********************************************************************
* Define Constants
**********************************************************************/

define( 'EVCA_DIR', plugin_dir_path( __FILE__ ) );
define( 'EVCA_INCLUDES', trailingslashit( EVCA_DIR . 'includes' ) );
define( 'EVCA_ASSETS', plugins_url( 'assets/', __FILE__ ) );

/**********************************************************************
* GET PLUGIN INFORMATION
**********************************************************************/

class EVCA_PLUGIN {

	static $plugin_meta;

	static public function GET( $key ){
		if( is_null( self::$plugin_meta ) ){
			self::$plugin_meta = get_plugin_data( __FILE__ );
		}
		if( array_key_exists( $key, self::$plugin_meta ) ){
			return self::$plugin_meta[ $key ];
		}
	}

	static public function FILTER_CLASS( $classes = array(), $defaults = array() ){
		if( $classes ){
			$classes  = explode( ' ', $classes );
			$classes  = array_filter( $classes );
			$classes  = array_map( 'sanitize_html_class', $classes );
			$defaults = array_merge( $defaults, $classes );
		}
		$defaults = implode( ' ', $defaults );
		return $defaults;
	}

	static function FILTER_LINK( $link ){
		if( function_exists( 'vc_build_link' ) ){
			$link = vc_build_link( $link );
		} elseif( ! empty( $atts['link'] ) ){
			$link = explode( '|', $link );
			if( is_array( $link ) ){
				$attributes = array();
				foreach( $link as $param ){
					$param = explode( ':', $param );
					if( ! empty( $param[0] ) && isset( $param[1] ) ){
						$attributes[ $param[0] ] = rawurldecode( $param[1] );
					}
				}
				$link = $attributes;
			}
		}
		$link = shortcode_atts( array(
			'url'    => '',
			'title'  => '',
			'target' => '',
		), $link );
		return $link;
	}

	static function FILTER_BORDER_RADIUS( $value ){
		if( preg_match_all( '/(\d+(\.\d+)?(em|ex|ch|rem|vw|vh|vmin|vmax|%|cm|mm|in|px|pt|pc))/', $value, $matches ) ){
			return implode( ' ', array_slice( $matches[0], 0, 4 ) );
		}
	}

	static public function load_textdomain(){
		load_plugin_textdomain( 'thrump-vc-addon', false, dirname( plugin_basename( __FILE__ ) ) . '/languages' );
	}

	static public function init(){
		if( defined( 'WPB_VC_VERSION' ) && version_compare( WPB_VC_VERSION, '4.9.2', '>=' ) ){
			include_once EVCA_INCLUDES . 'init.php';
		}
	}

}

/**********************************************************************
* Init plugin
**********************************************************************/

add_action( 'plugins_loaded', array( 'EVCA_PLUGIN', 'init' ) );
add_action( 'init', array( 'EVCA_PLUGIN', 'load_textdomain' ) );
