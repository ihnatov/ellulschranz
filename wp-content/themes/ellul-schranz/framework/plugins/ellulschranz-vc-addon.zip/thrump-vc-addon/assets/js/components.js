(function($) {

	"use strict";

/* ==========================================================================
   exists - Check if an element exists
   ========================================================================== */

	function exists(e) {
		return $(e).length > 0;
	}

/* ==========================================================================
   isTouchDevice - return true if it is a touch device
   ========================================================================== */

	function isTouchDevice() {
		return !!('ontouchstart' in window) || ( !! ('onmsgesturechange' in window) && !! window.navigator.maxTouchPoints);
	}

/* ==========================================================================
   setDimensionsPieCharts
   ========================================================================== */

	function setDimensionsPieCharts() {

		$('.pie-chart').each(function() {

			var $t = $(this),
				n = $t.parent().width(),
				r = $t.attr("data-barSize");

			if (n < r) {
				r = n;
			}

			$t.css({
				"height": r,
				"width": r,
				"line-height": r + "px"
			});

			$t.find("i").css({
				"line-height": r + "px",
				"font-size": r / 3
			});

		});

	}

/* ==========================================================================
   animatePieCharts
   ========================================================================== */

	function animatePieCharts() {

		if(typeof $.fn.easyPieChart !== 'undefined'){

			$('.pie-chart:in-viewport').each(function() {

				var $t = $(this),
					n = $t.parent().width(),
					r = $t.attr("data-barSize"),
					l = "square";

				if ($t.attr("data-lineCap") !== undefined) {
					l = $t.attr("data-lineCap");
				}

				if (n < r) {
					r = n;
				}

				$t.easyPieChart({
					animate: 1300,
					lineCap: l,
					lineWidth: $t.attr("data-lineWidth"),
					size: r,
					barColor: $t.attr("data-barColor"),
					trackColor: $t.attr("data-trackColor"),
					scaleColor: "transparent",
					onStep: function(from, to, percent) {
						$(this.el).find('.pie-chart-percent span').text(Math.round(percent));
					}

				});

			});

		}

	}

/* ==========================================================================
   animateMilestones
   ========================================================================== */

	function animateMilestones() {

		$('.milestone:in-viewport').each(function() {

			var $t = $(this),
				n = $t.find(".milestone-value").attr("data-stop"),
				r = parseInt($t.find(".milestone-value").attr("data-speed"), 10);

			if (!$t.hasClass("already-animated")) {
				$t.addClass("already-animated");
				$({
					countNum: $t.find(".milestone-value").text()
				}).animate({
					countNum: n
				}, {
					duration: r,
					easing: "linear",
					step: function() {
						$t.find(".milestone-value").text(Math.floor(this.countNum));
					},
					complete: function() {
						$t.find(".milestone-value").text(this.countNum);
					}
				});
			}

		});

	}

/* ==========================================================================
   animateProgressBars
   ========================================================================== */

	function animateProgressBars() {

		$('.progress-bar .progress-bar-outer:in-viewport').each(function() {

			var $t = $(this);

			if ($t.attr("data-progress-bar-outer-color") !== undefined) {
				$t.css("background-color", $t.attr("data-progress-bar-outer-color"));
			}

			if (!$t.hasClass("already-animated")) {
				$t.addClass("already-animated").animate({
					width: $t.attr("data-width") + "%"
				}, 2000);
			}

		});

	}

/* ==========================================================================
   handleMaxHeight
   ========================================================================== */

   	function handleMaxHeight() {

		var maxHeight = -1;

		if ($(window).width() > 767) {

			var $services = $('.services-list li'),
				width     = ( 100 / $services.length ) + '%';

			$services.css({
				'height' : '',
				'width' : width
			});

			$services.each(function() {
				maxHeight = Math.max( maxHeight, $(this).outerHeight() );
			});

			$services.css( 'height', maxHeight );

		} else {

			$('.services-list li').each(function(){
				this.style = '';
			})

		}

	}

/* ==========================================================================
   When document is ready, do
   ========================================================================== */

	$(document).ready(function() {

		setDimensionsPieCharts();

		animatePieCharts();
		animateMilestones();
		animateProgressBars();

		handleMaxHeight();


		// bxSlider - responsive slider
		// http://bxslider.com/options

		if(typeof $.fn.bxSlider !== 'undefined'){

			$('.bxslider .slides').bxSlider({
				 mode: 'fade',							// Type of transition between slides: 'horizontal', 'vertical', 'fade'
				 speed: 500,							// Slide transition duration (in ms)
				 infiniteLoop: true,					// If true, clicking "Next" while on the last slide will transition to the first slide and vice-versa.
				 hideControlOnEnd: false,				// If true, "Next" control will be hidden on last slide and vice-versa. Only used when infiniteLoop: false
				 pager: true,							// If true, a pager will be added
				 pagerType: 'full',						// If 'full', a pager link will be generated for each slide. If 'short', a x / y pager will be used (ex. 1/5)
				 controls: true,						// If true, "Next" / "Prev" controls will be added
				 auto: true,							// If true, slides will automatically transition
				 pause: 4000,							// The amount of time (in ms) between each auto transition
				 autoHover: true,						// Auto show will pause when mouse hovers over slider
				 useCSS: false 							// If true, CSS transitions will be used for animations. False, jQuery animations. Setting to false fixes problem with jQuery 2.1.0 and mode:horizontal
			});

			$('.testimonial-slider .slides').bxSlider({
				 mode: 'fade',							// Type of transition between slides: 'horizontal', 'vertical', 'fade'
				 speed: 500,							// Slide transition duration (in ms)
				 infiniteLoop: true,					// If true, clicking "Next" while on the last slide will transition to the first slide and vice-versa.
				 hideControlOnEnd: false,				// If true, "Next" control will be hidden on last slide and vice-versa. Only used when infiniteLoop: false
				 pager: true,							// If true, a pager will be added
				 pagerType: 'full',						// If 'full', a pager link will be generated for each slide. If 'short', a x / y pager will be used (ex. 1/5)
				 controls: false,						// If true, "Next" / "Prev" controls will be added
				 auto: true,							// If true, slides will automatically transition
				 pause: 4000,							// The amount of time (in ms) between each auto transition
				 autoHover: true,						// Auto show will pause when mouse hovers over slider
				 useCSS: false 							// If true, CSS transitions will be used for animations. False, jQuery animations. Setting to false fixes problem with jQuery 2.1.0 and mode:horizontal
			});

			$('.testimonial-slider-2 .slides').bxSlider({
				 mode: 'fade',							// Type of transition between slides: 'horizontal', 'vertical', 'fade'
				 speed: 500,							// Slide transition duration (in ms)
				 infiniteLoop: true,					// If true, clicking "Next" while on the last slide will transition to the first slide and vice-versa.
				 hideControlOnEnd: false,				// If true, "Next" control will be hidden on last slide and vice-versa. Only used when infiniteLoop: false
				 pager: true,							// If true, a pager will be added
				 pagerType: 'full',						// If 'full', a pager link will be generated for each slide. If 'short', a x / y pager will be used (ex. 1/5)
				 controls: false,						// If true, "Next" / "Prev" controls will be added
				 auto: true,							// If true, slides will automatically transition
				 pause: 4000,							// The amount of time (in ms) between each auto transition
				 autoHover: true,						// Auto show will pause when mouse hovers over slider
				 useCSS: false 							// If true, CSS transitions will be used for animations. False, jQuery animations. Setting to false fixes problem with jQuery 2.1.0 and mode:horizontal
			});

		}

		// Magnific PopUp - responsive lightbox
		// http://dimsemenov.com/plugins/magnific-popup/documentation.html

		if(typeof $.fn.magnificPopup !== 'undefined'){

			$('.magnificPopup').magnificPopup({
				disableOn: 400,
				closeOnContentClick: true,
				type: 'image'
			});

			$('.magnificPopup-gallery').magnificPopup({
				disableOn: 400,
				type: 'image',
				gallery: {
					enabled: true
				}
			});

			$('.magnificPopup-modal').magnificPopup({
				type: 'inline',
				preloader: false,
				modal: true
			});

			$(document).on('click', '.magnificPopup-modal-dismiss', function (e) {
				e.preventDefault();
				$.magnificPopup.close();
			});

		}

		// gMap -  embed Google Maps into your website; uses Google Maps v3
		// http://labs.mario.ec/jquery-gmap/

		if(typeof $.fn.gMap !== 'undefined'){

			//handleGoogleMapHeight();

			$('.google-map').each(function() {

				var $t = $(this),
					mapZoom = 15,
					mapAddress = $t.attr("data-address"),
					mapCaption = $t.attr("data-caption"),
					mapType = "ROADMAP",
					mapHeight = $t.attr("data-mapheight"),
					popUp = false;

				if ($t.attr("data-zoom") !== undefined) {
					mapZoom = parseInt($t.attr("data-zoom"),10);
				}

				if ($t.attr("data-mapHeight") !== undefined) {
					$t.css( "height", mapHeight+'px');
				}

				if ($t.attr("data-maptype") !== undefined) {
					mapType = $t.attr("data-maptype");
				}

				if ($t.attr("data-popup") !== undefined) {
					popUp = $t.data("popup");
				}

				$t.gMap({
					maptype: mapType,
					scrollwheel: false,
					zoom: mapZoom,
					markers: [{
						address: mapAddress,
						html: mapCaption,
						popup: popUp
					}],
					controls: {
						panControl: true,
						zoomControl: true,
						mapTypeControl: true,
						scaleControl: false,
						streetViewControl: false,
						overviewMapControl: false
					}
				});

			});

		}


		// countdown

		if (typeof $.fn.countdown !== 'undefined') {

			if( typeof evca_countdown == 'object' ){
				$.countdown.setDefaults( evca_countdown );
			}

			$('.evca-countdown').each(function(){

				$(this).countdown({ until: new Date( $(this).data('countdown') ) });

			});

		}

		//

	});

/* ==========================================================================
   When the window is scrolled, do
   ========================================================================== */

	$(window).scroll(function() {

		animateMilestones();
		animatePieCharts();
		animateProgressBars();

	});

/* ==========================================================================
   When the window is resized, do
   ========================================================================== */

	$(window).resize(function() {

		handleMaxHeight();

	});


})(jQuery);

// non jQuery scripts below
