(function($){
	$('.evca-image-select .evca-image-option').on('change',function(){
		var	$parent = $(this).closest('.evca-image-select');
		$parent.find('label').removeClass('active');
		$(this).parent().addClass('active');
		$parent.find('.evca-image-value').val( this.value ).change();
	});
})(jQuery);
