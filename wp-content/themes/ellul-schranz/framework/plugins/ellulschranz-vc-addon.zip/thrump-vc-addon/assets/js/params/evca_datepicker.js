(function($){
	if( typeof $.fn.datepicker == 'function' && typeof evca_datepicker == 'object' ){
		$('.evca-datepicker').datepicker( evca_datepicker );
	}
})(jQuery);
