/**
 * Salient buttonset init.
 *
 * @package Salient
 * @author ThemeNectar
 */
 /* global jQuery */
jQuery(document).ready(function ($) {
  "use strict";
  $('[id*="nectar-metabox-"] .buttonset').buttonset();
});
